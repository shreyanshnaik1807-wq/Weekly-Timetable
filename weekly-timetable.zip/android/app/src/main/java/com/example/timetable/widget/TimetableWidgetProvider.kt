package com.example.timetable.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.timetable.MainActivity
import com.example.timetable.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * TimetableWidgetProvider
 * 
 * Implements Android 13 (API 33) AppWidgetProvider lifecycle callbacks.
 * Configured for deployment on Android 13 Smart Boards (e.g. Senses 86" 4K interactive displays).
 */
class TimetableWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_WIDGET_REFRESH = "com.example.timetable.action.WIDGET_REFRESH"

        /**
         * Static helper to trigger a full update across all active widget instances.
         */
        fun requestUpdateAll(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, TimetableWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            if (appWidgetIds.isNotEmpty()) {
                val intent = Intent(context, TimetableWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds)
                }
                context.sendBroadcast(intent)
            }
        }
    }

    /**
     * Called on widget placement and at scheduled intervals (updatePeriodMillis).
     */
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Iterate through all active instances on the launcher
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    /**
     * Handles custom broadcasts such as manual user refresh or data sync.
     */
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_WIDGET_REFRESH) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, TimetableWidgetProvider::class.java)
            val ids = appWidgetManager.getAppWidgetIds(componentName)
            onUpdate(context, appWidgetManager, ids)
        }
    }

    /**
     * Binds state and intent handlers to RemoteViews for a specific widget instance.
     */
    private fun updateAppWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_layout)

        // 1. Format current date & time for large display readouts
        val dateFormat = SimpleDateFormat("EEEE • MMM d", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        views.setTextViewText(R.id.widget_date_subtitle, dateFormat.format(now))
        views.setTextViewText(
            R.id.widget_last_updated,
            "Updated at ${timeFormat.format(now)}"
        )

        // 2. Load schedule data (Sample active event or pulled from SharedPreferences/Room)
        val prefs = context.getSharedPreferences("timetable_widget_data", Context.MODE_PRIVATE)
        val eventTitle = prefs.getString("current_event_title", "CS301: Advanced Cloud Architecture")
        val eventTime = prefs.getString("current_event_time", "10:00 AM — 11:30 AM (Room 402 • Hall A)")
        val eventInstructor = prefs.getString("current_event_details", "Instructor: Prof. Sterling • Lecture & Lab")

        views.setTextViewText(R.id.widget_event_title, eventTitle)
        views.setTextViewText(R.id.widget_event_time, eventTime)
        views.setTextViewText(R.id.widget_event_details, eventInstructor)

        // 3. Android 13 (API 33) PendingIntent: Launch Main Fullscreen App Activity
        // Note: PendingIntent.FLAG_IMMUTABLE is strictly required on Android 12+ (API 31/33)
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val launchPendingIntent = PendingIntent.getActivity(
            context,
            appWidgetId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Attach launch click listener to both the card body and the explicit action button
        views.setOnClickPendingIntent(R.id.widget_content_card, launchPendingIntent)
        views.setOnClickPendingIntent(R.id.widget_action_button, launchPendingIntent)

        // 4. Attach Refresh Broadcast Click Listener to status badge
        val refreshIntent = Intent(context, TimetableWidgetProvider::class.java).apply {
            action = ACTION_WIDGET_REFRESH
        }
        val refreshPendingIntent = PendingIntent.getBroadcast(
            context,
            appWidgetId + 1000,
            refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_status_badge, refreshPendingIntent)

        // 5. Instruct AppWidgetManager to update the current widget on the launcher
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
