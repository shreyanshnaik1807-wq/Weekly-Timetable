import React from 'react';
import { X, Sliders, Clock, Calendar } from 'lucide-react';
import { ScheduleSettings } from '../types';
import { formatDisplayTime } from '../utils/time';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ScheduleSettings;
  onUpdateSettings: (newSettings: Partial<ScheduleSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div
        id="settings-modal-dialog"
        className="w-full max-w-md bg-[#111111] rounded-3xl lg:rounded-[2.5rem] shadow-2xl border border-neutral-800 text-white flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150 overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-blue-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                Timetable Settings
              </h2>
              <p className="text-xs text-neutral-400 font-medium">
                Configure time range and display preferences
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Time Range */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold font-mono text-neutral-500 uppercase tracking-widest">
              Daylight Hours Window
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold font-mono text-neutral-400 mb-1">
                  Start Hour
                </label>
                <select
                  value={settings.startHour}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    if (val < settings.endHour) {
                      onUpdateSettings({ startHour: val });
                    }
                  }}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#1a1a1a] text-white border border-neutral-800 rounded-2xl font-mono focus:bg-[#202020] focus:border-blue-500 focus:outline-none"
                >
                  {[5, 6, 7, 8, 9, 10].map((h) => (
                    <option key={h} value={h}>
                      {formatDisplayTime(`${String(h).padStart(2, '0')}:00`, settings.timeFormat24h)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold font-mono text-neutral-400 mb-1">
                  End Hour
                </label>
                <select
                  value={settings.endHour}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    if (val > settings.startHour) {
                      onUpdateSettings({ endHour: val });
                    }
                  }}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#1a1a1a] text-white border border-neutral-800 rounded-2xl font-mono focus:bg-[#202020] focus:border-blue-500 focus:outline-none"
                >
                  {[17, 18, 19, 20, 21, 22, 23].map((h) => (
                    <option key={h} value={h}>
                      {formatDisplayTime(`${String(h).padStart(2, '0')}:00`, settings.timeFormat24h)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Time Format */}
          <div className="space-y-3 pt-2 border-t border-neutral-800">
            <h3 className="text-xs font-bold font-mono text-neutral-500 uppercase tracking-widest">
              Display Format
            </h3>

            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#161616] border border-neutral-800">
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-blue-400" />
                <div>
                  <div className="text-xs font-bold text-white">24-Hour Time Format</div>
                  <div className="text-[11px] font-mono text-neutral-400">
                    {settings.timeFormat24h ? 'e.g. 14:00' : 'e.g. 2:00 PM'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onUpdateSettings({ timeFormat24h: !settings.timeFormat24h })}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.timeFormat24h ? 'bg-blue-600' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    settings.timeFormat24h ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Show Weekends */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#161616] border border-neutral-800">
              <div className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-blue-400" />
                <div>
                  <div className="text-xs font-bold text-white">Show Weekends (Saturday & Sunday)</div>
                  <div className="text-[11px] font-mono text-neutral-400">
                    {settings.showWeekends ? 'Showing full 7-day week' : 'Showing 5-day school/work week'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onUpdateSettings({ showWeekends: !settings.showWeekends })}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.showWeekends ? 'bg-blue-600' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    settings.showWeekends ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-[#0d0d0d] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full transition shadow-[0_0_12px_rgba(37,99,235,0.4)]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
