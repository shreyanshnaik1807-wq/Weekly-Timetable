import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { DayOfWeek, DAYS_OF_WEEK, ScheduleEvent, ScheduleSettings } from '../types';
import {
  getCurrentDayOfWeek,
  timeToMinutes,
  formatDisplayTime,
  getDurationString,
} from '../utils/time';
import { EventCard } from './EventCard';

interface DayViewProps {
  events: ScheduleEvent[];
  settings: ScheduleSettings;
  searchQuery?: string;
  categoryFilter?: string;
  onSelectEvent: (event: ScheduleEvent) => void;
  onAddEventAtSlot: (day: DayOfWeek, startTime: string) => void;
  onDeleteEvent: (id: string) => void;
  onDuplicateEvent: (event: ScheduleEvent) => void;
  onAdjustDuration?: (eventId: string, deltaMinutes: number) => void;
}

export const DayView: React.FC<DayViewProps> = ({
  events,
  settings,
  searchQuery = '',
  categoryFilter = 'all',
  onSelectEvent,
  onAddEventAtSlot,
  onDeleteEvent,
  onDuplicateEvent,
  onAdjustDuration,
}) => {
  const today = getCurrentDayOfWeek();
  const [selectedDay, setSelectedDay] = useState<DayOfWeek>(today);
  const { startHour, endHour, timeFormat24h } = settings;

  const currentIndex = DAYS_OF_WEEK.indexOf(selectedDay);

  const handlePrevDay = () => {
    const nextIdx = (currentIndex - 1 + 7) % 7;
    setSelectedDay(DAYS_OF_WEEK[nextIdx]);
  };

  const handleNextDay = () => {
    const nextIdx = (currentIndex + 1) % 7;
    setSelectedDay(DAYS_OF_WEEK[nextIdx]);
  };

  // Filter events for this day
  const dayEvents = events
    .filter((ev) => ev.day === selectedDay)
    .filter((ev) => {
      if (categoryFilter !== 'all' && ev.category !== categoryFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          ev.title.toLowerCase().includes(q) ||
          ev.code?.toLowerCase().includes(q) ||
          ev.location?.toLowerCase().includes(q) ||
          ev.instructor?.toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  return (
    <div id="day-view-container" className="w-full bg-[#111111] rounded-3xl lg:rounded-[2.5rem] border border-neutral-800 shadow-2xl overflow-hidden flex flex-col text-white">
      {/* Day Selector Header */}
      <div className="p-4 sm:p-6 border-b border-neutral-800 bg-[#0d0d0d]">
        {/* Navigation row */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrevDay}
              className="p-2 rounded-full bg-[#1a1a1a] border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition"
              title="Previous day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNextDay}
              className="p-2 rounded-full bg-[#1a1a1a] border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition"
              title="Next day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <h3 className="text-lg sm:text-xl font-black tracking-tight text-white ml-1">
              {selectedDay}
            </h3>

            {selectedDay === today && (
              <span className="px-2.5 py-0.5 text-[9px] font-black uppercase tracking-wider bg-blue-600 text-white rounded-full shadow-[0_0_8px_rgba(37,99,235,0.6)]">
                Today
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {selectedDay !== today && (
              <button
                type="button"
                onClick={() => setSelectedDay(today)}
                className="px-3 py-1.5 text-xs font-bold text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 rounded-full border border-blue-500/30 transition"
              >
                Go to Today
              </button>
            )}

            <button
              type="button"
              onClick={() => onAddEventAtSlot(selectedDay, '09:00')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full transition shadow-[0_0_12px_rgba(37,99,235,0.4)]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Event</span>
            </button>
          </div>
        </div>

        {/* Day Pills Carousel (Bento Pill Bar) */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 p-1.5 bg-[#141414] rounded-full border border-neutral-800/80 scrollbar-none">
          {DAYS_OF_WEEK.map((day) => {
            const isSelected = day === selectedDay;
            const isToday = day === today;
            const count = events.filter((e) => e.day === day).length;

            return (
              <button
                key={day}
                type="button"
                onClick={() => setSelectedDay(day)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition shrink-0 ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-neutral-400 hover:text-white hover:bg-[#1f1f1f]'
                }`}
              >
                <span>{day.slice(0, 3)}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    isSelected
                      ? 'bg-blue-800/80 text-white'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {count}
                </span>
                {isToday && !isSelected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_6px_rgba(59,130,246,0.8)]" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Day Events Timeline Content */}
      <div className="p-4 sm:p-6 min-h-[400px]">
        {dayEvents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-14 h-14 rounded-3xl bg-[#1a1a1a] border border-neutral-800 text-blue-400 flex items-center justify-center mb-3 shadow-inner">
              <Sparkles className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-white">
              No events scheduled for {selectedDay}
            </h4>
            <p className="text-xs text-neutral-400 max-w-sm mt-1 mb-5">
              Keep your day open for rest, or plan ahead by adding a class, meeting, study block, or workout.
            </p>
            <button
              type="button"
              onClick={() => onAddEventAtSlot(selectedDay, '09:00')}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full transition shadow-[0_0_15px_rgba(37,99,235,0.4)]"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Event for {selectedDay}</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3.5 max-w-2xl mx-auto">
            {dayEvents.map((event) => (
              <div key={event.id} className="min-h-[100px]">
                <EventCard
                  event={event}
                  is24h={timeFormat24h}
                  compact={false}
                  onClick={() => onSelectEvent(event)}
                  onDelete={() => onDeleteEvent(event.id)}
                  onDuplicate={() => onDuplicateEvent(event)}
                  onAdjustDuration={
                    onAdjustDuration
                      ? (delta) => onAdjustDuration(event.id, delta)
                      : undefined
                  }
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
