import React, { useState } from 'react';
import {
  X,
  Plus,
  Copy,
  Trash2,
  Check,
  RotateCcw,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { Timetable } from '../types';

interface ScheduleManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  timetables: Timetable[];
  activeTimetableId: string;
  onSelectTimetable: (id: string) => void;
  onCreateTimetable: (name: string, description?: string) => void;
  onDuplicateTimetable: (sourceId: string) => void;
  onRenameTimetable: (id: string, newName: string) => void;
  onDeleteTimetable: (id: string) => void;
  onResetPresets: () => void;
}

export const ScheduleManagerModal: React.FC<ScheduleManagerModalProps> = ({
  isOpen,
  onClose,
  timetables,
  activeTimetableId,
  onSelectTimetable,
  onCreateTimetable,
  onDuplicateTimetable,
  onRenameTimetable,
  onDeleteTimetable,
  onResetPresets,
}) => {
  const [newScheduleName, setNewScheduleName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState('');

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newScheduleName.trim()) return;
    onCreateTimetable(newScheduleName.trim());
    setNewScheduleName('');
    setIsCreating(false);
  };

  const startRename = (t: Timetable) => {
    setEditingId(t.id);
    setEditNameValue(t.name);
  };

  const saveRename = (id: string) => {
    if (editNameValue.trim()) {
      onRenameTimetable(id, editNameValue.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div
        id="schedule-manager-modal"
        className="w-full max-w-lg bg-[#111111] rounded-3xl lg:rounded-[2.5rem] shadow-2xl border border-neutral-800 text-white flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150 overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-blue-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                Manage Timetables
              </h2>
              <p className="text-xs text-neutral-400 font-medium">
                Create, switch, or customize separate weekly schedules
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Create new schedule block */}
          {isCreating ? (
            <form
              onSubmit={handleCreate}
              className="p-4 bg-[#1a1a1a] border border-neutral-800 rounded-2xl space-y-3"
            >
              <h3 className="text-xs font-bold font-mono text-neutral-400 uppercase tracking-wider">
                Create New Timetable
              </h3>
              <input
                id="new-timetable-name-input"
                type="text"
                value={newScheduleName}
                onChange={(e) => setNewScheduleName(e.target.value)}
                placeholder="e.g. Spring 2027, Work & Workout, Exam Prep"
                className="w-full px-4 py-2.5 text-sm bg-[#111111] text-white placeholder:text-neutral-500 border border-neutral-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                autoFocus
                required
              />
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-1.5 text-xs font-bold text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-full transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full shadow-[0_0_12px_rgba(37,99,235,0.4)] transition"
                >
                  Create
                </button>
              </div>
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setIsCreating(true)}
              className="w-full py-3.5 px-4 rounded-2xl border-2 border-dashed border-neutral-800 hover:border-blue-500 text-neutral-300 hover:text-blue-400 flex items-center justify-center gap-2 text-xs font-bold transition bg-[#161616] hover:bg-blue-600/5"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Blank Timetable</span>
            </button>
          )}

          {/* List of timetables */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold font-mono text-neutral-500 uppercase tracking-widest">
              Saved Schedules ({timetables.length})
            </h3>
            {timetables.map((t) => {
              const isActive = t.id === activeTimetableId;
              const isRenaming = editingId === t.id;

              return (
                <div
                  key={t.id}
                  className={`p-4 rounded-2xl border transition flex items-center justify-between gap-3 ${
                    isActive
                      ? 'border-blue-500/40 bg-blue-600/10 shadow-sm'
                      : 'border-neutral-800 bg-[#161616] hover:border-neutral-700'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    {isRenaming ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editNameValue}
                          onChange={(e) => setEditNameValue(e.target.value)}
                          className="px-3 py-1.5 text-sm bg-[#111111] text-white border border-blue-500 rounded-xl w-full"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') saveRename(t.id);
                            if (e.key === 'Escape') setEditingId(null);
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => saveRename(t.id)}
                          className="p-1.5 text-emerald-400 hover:bg-emerald-500/20 rounded-lg"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => onSelectTimetable(t.id)}
                        className="cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white truncate">
                            {t.name}
                          </h4>
                          {isActive && (
                            <span className="px-2 py-0.5 text-[9px] font-black uppercase tracking-wider bg-blue-600 text-white rounded-full shadow-[0_0_8px_rgba(37,99,235,0.6)]">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] font-mono text-neutral-400 mt-0.5">
                          {t.events.length} {t.events.length === 1 ? 'event' : 'events'}
                          {t.description ? ` • ${t.description}` : ''}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {!isActive && !isRenaming && (
                      <button
                        type="button"
                        onClick={() => onSelectTimetable(t.id)}
                        className="px-3 py-1 text-xs font-bold text-blue-400 hover:text-white bg-blue-500/10 hover:bg-blue-600 rounded-full border border-blue-500/30 transition"
                      >
                        Switch
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onDuplicateTimetable(t.id)}
                      className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition"
                      title="Clone timetable"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    {!isRenaming && (
                      <button
                        type="button"
                        onClick={() => startRename(t)}
                        className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition text-xs font-bold font-mono"
                        title="Rename"
                      >
                        Rename
                      </button>
                    )}
                    {timetables.length > 1 && (
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Delete timetable "${t.name}"? This cannot be undone.`)) {
                            onDeleteTimetable(t.id);
                          }
                        }}
                        className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/20 rounded-xl transition"
                        title="Delete timetable"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Reset to Presets */}
          <div className="pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => {
                if (confirm('Reset to default preset timetables (University, Work, and Lifestyle)?')) {
                  onResetPresets();
                  onClose();
                }
              }}
              className="text-xs text-neutral-400 hover:text-white flex items-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore default starter schedules</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-[#0d0d0d] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full transition shadow-[0_0_12px_rgba(37,99,235,0.4)]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
