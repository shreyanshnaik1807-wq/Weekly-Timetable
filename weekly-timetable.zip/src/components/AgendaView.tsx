import React from 'react';
import { Plus, Calendar, Sparkles } from 'lucide-react';
import { DAYS_OF_WEEK, WORK_DAYS, DayOfWeek, ScheduleEvent, ScheduleSettings } from '../types';
import { getCurrentDayOfWeek, timeToMinutes } from '../utils/time';
import { EventCard } from './EventCard';

interface AgendaViewProps {
  events: ScheduleEvent[];
  settings: ScheduleSettings;
  searchQuery?: string;
  categoryFilter?: string;
  onSelectEvent: (event: ScheduleEvent) => void;
  onAddEventAtSlot: (day: DayOfWeek, startTime: string) => void;
  onDeleteEvent: (id: string) => void;
  onDuplicateEvent: (event: ScheduleEvent) => void;
  onAdjustDuration?: (eventId: string, deltaMinutes: number) => void;
}

export const AgendaView: React.FC<AgendaViewProps> = ({
  events,
  settings,
  searchQuery = '',
  categoryFilter = 'all',
  onSelectEvent,
  onAddEventAtSlot,
  onDeleteEvent,
  onDuplicateEvent,
  onAdjustDuration,
}) => {
  const { showWeekends, timeFormat24h } = settings;
  const daysToShow = showWeekends ? DAYS_OF_WEEK : WORK_DAYS;
  const today = getCurrentDayOfWeek();

  const filteredEvents = events.filter((ev) => {
    if (categoryFilter !== 'all' && ev.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        ev.title.toLowerCase().includes(q) ||
        ev.code?.toLowerCase().includes(q) ||
        ev.location?.toLowerCase().includes(q) ||
        ev.instructor?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalFiltered = filteredEvents.length;

  return (
    <div id="agenda-view-container" className="w-full bg-[#111111] rounded-3xl lg:rounded-[2.5rem] border border-neutral-800 shadow-2xl p-4 sm:p-8 text-white">
      {totalFiltered === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-3xl bg-[#1a1a1a] border border-neutral-800 text-blue-400 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Calendar className="w-6 h-6" />
          </div>
          <h4 className="text-base font-bold text-white">No events found</h4>
          <p className="text-xs text-neutral-400 mt-1 mb-4">
            Try adjusting your search query or category filter.
          </p>
        </div>
      ) : (
        <div className="space-y-8 max-w-4xl mx-auto">
          {daysToShow.map((day) => {
            const isToday = day === today;
            const dayEvents = filteredEvents
              .filter((e) => e.day === day)
              .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

            if (dayEvents.length === 0) return null;

            return (
              <section key={day} className="space-y-3.5">
                <div className="flex items-center justify-between border-b border-neutral-800/80 pb-2.5">
                  <div className="flex items-center gap-2">
                    <h3 className={`text-base sm:text-lg font-black tracking-tight ${isToday ? 'text-blue-400' : 'text-white'}`}>
                      {day}
                    </h3>
                    {isToday && (
                      <span className="px-2.5 py-0.5 text-[9px] font-black uppercase tracking-wider bg-blue-600 text-white rounded-full shadow-[0_0_8px_rgba(37,99,235,0.6)]">
                        Today
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => onAddEventAtSlot(day, '10:00')}
                    className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 bg-[#1a1a1a] hover:bg-neutral-800 px-3 py-1 rounded-full border border-neutral-800 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {dayEvents.map((event) => (
                    <div key={event.id} className="min-h-[96px]">
                      <EventCard
                        event={event}
                        is24h={timeFormat24h}
                        compact={false}
                        onClick={() => onSelectEvent(event)}
                        onDelete={() => onDeleteEvent(event.id)}
                        onDuplicate={() => onDuplicateEvent(event)}
                        onAdjustDuration={
                          onAdjustDuration
                            ? (delta) => onAdjustDuration(event.id, delta)
                            : undefined
                        }
                      />
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
};
