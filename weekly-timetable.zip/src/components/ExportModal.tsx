import React, { useState, useRef } from 'react';
import {
  X,
  Calendar,
  FileDown,
  Upload,
  Printer,
  Copy,
  Check,
  Share2,
  FileJson,
  Smartphone,
} from 'lucide-react';
import { Timetable } from '../types';
import { exportTimetablesJSON } from '../utils/storage';
import { generateICalendar, formatDisplayTime } from '../utils/time';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  timetables: Timetable[];
  activeTimetable: Timetable;
  onImportTimetables: (imported: Timetable[]) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  timetables,
  activeTimetable,
  onImportTimetables,
}) => {
  const [copiedText, setCopiedText] = useState(false);
  const [importError, setImportError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Export to .ics
  const handleExportICS = () => {
    const icsContent = generateICalendar(activeTimetable.events, activeTimetable.name);
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeName = activeTimetable.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    link.download = `${safeName || 'weekly-timetable'}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export to JSON backup
  const handleExportJSON = () => {
    exportTimetablesJSON(timetables);
  };

  // Import JSON handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].events) {
          onImportTimetables(parsed);
          setImportError('');
          onClose();
        } else {
          setImportError('Invalid backup file structure.');
        }
      } catch (err) {
        setImportError('Could not parse JSON file.');
      }
    };
    reader.readAsText(file);
  };

  // Copy Plain Text Summary
  const handleCopySummary = () => {
    const lines = [`🗓️ ${activeTimetable.name.toUpperCase()} (Weekly Timetable)`, ''];
    const daysOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    daysOrder.forEach((day) => {
      const dayEvents = activeTimetable.events.filter((e) => e.day === day);
      if (dayEvents.length > 0) {
        lines.push(`--- ${day.toUpperCase()} ---`);
        dayEvents.forEach((e) => {
          const loc = e.location ? ` @ ${e.location}` : '';
          const code = e.code ? ` [${e.code}]` : '';
          lines.push(`• ${e.startTime} - ${e.endTime}: ${e.title}${code}${loc}`);
        });
        lines.push('');
      }
    });

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Print timetable
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div
        id="export-modal-dialog"
        className="w-full max-w-lg bg-[#111111] rounded-3xl lg:rounded-[2.5rem] shadow-2xl border border-neutral-800 text-white flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150 overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-blue-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                Export & Sync Schedule
              </h2>
              <p className="text-xs text-neutral-400 font-medium">
                {activeTimetable.name} ({activeTimetable.events.length} events)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {importError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-2xl text-xs font-medium">
              {importError}
            </div>
          )}

          {/* iCalendar (.ics) export - Google / Apple / Outlook */}
          <div className="p-4 rounded-2xl border border-neutral-800 bg-[#161616] hover:border-blue-500/50 hover:bg-blue-600/5 transition flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-blue-400">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  Export to Calendar (.ICS)
                </h3>
                <p className="text-xs text-neutral-400">
                  Compatible with Google Calendar, Apple Calendar, and Outlook.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleExportICS}
              className="px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shrink-0 transition shadow-[0_0_12px_rgba(37,99,235,0.4)]"
            >
              Download .ics
            </button>
          </div>

          {/* Print / Save as PDF */}
          <div className="p-4 rounded-2xl border border-neutral-800 bg-[#161616] hover:border-emerald-500/50 hover:bg-emerald-600/5 transition flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-emerald-400">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  Print or Save as PDF
                </h3>
                <p className="text-xs text-neutral-400">
                  Clean, printer-friendly layout for desktop or wall posters.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shrink-0 transition shadow-[0_0_12px_rgba(16,185,129,0.4)]"
            >
              Print View
            </button>
          </div>

          {/* Copy Plaintext Summary */}
          <div className="p-4 rounded-2xl border border-neutral-800 bg-[#161616] hover:border-amber-500/50 hover:bg-amber-600/5 transition flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-[#1a1a1a] border border-neutral-800 text-amber-400">
                <Copy className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  Copy Weekly Summary
                </h3>
                <p className="text-xs text-neutral-400">
                  Formatted text to paste into messages, Slack, or notes.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCopySummary}
              className="px-4 py-2 rounded-full bg-[#111111] border border-neutral-800 hover:border-neutral-700 text-white text-xs font-bold shrink-0 transition flex items-center gap-1.5"
            >
              {copiedText ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <span>Copy Text</span>
              )}
            </button>
          </div>

          {/* JSON Backup & Restore section */}
          <div className="p-4 rounded-2xl border border-neutral-800 bg-[#161616] space-y-3">
            <div className="flex items-center gap-2">
              <FileJson className="w-4 h-4 text-neutral-400" />
              <h4 className="text-xs font-bold font-mono text-neutral-300 uppercase tracking-wider">
                Backup & Transfer Across Devices
              </h4>
            </div>
            <p className="text-xs text-neutral-400">
              Download your complete schedules as a JSON file to transfer between your computer, phone, or tablet.
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleExportJSON}
                className="flex-1 py-2.5 px-3 text-xs font-bold rounded-full bg-[#111111] border border-neutral-800 hover:border-neutral-700 text-neutral-200 hover:text-white flex items-center justify-center gap-1.5 transition"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>Export Backup (JSON)</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2.5 px-3 text-xs font-bold rounded-full bg-[#111111] border border-neutral-800 hover:border-neutral-700 text-neutral-200 hover:text-white flex items-center justify-center gap-1.5 transition"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import Backup</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-[#0d0d0d] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-full transition shadow-[0_0_12px_rgba(37,99,235,0.4)]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
