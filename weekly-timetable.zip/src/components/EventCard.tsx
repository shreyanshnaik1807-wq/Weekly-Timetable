import React from 'react';
import { Clock, MapPin, User, AlertCircle, Copy, Trash2, Edit3 } from 'lucide-react';
import { COLOR_SCHEMES, CATEGORIES } from '../constants/colors';
import { formatDisplayTime, getDurationString } from '../utils/time';
import { ScheduleEvent } from '../types';

interface EventCardProps {
  event: ScheduleEvent;
  is24h?: boolean;
  compact?: boolean;
  hasConflict?: boolean;
  onClick?: () => void;
  onDelete?: (e: React.MouseEvent) => void;
  onDuplicate?: (e: React.MouseEvent) => void;
  onAdjustDuration?: (deltaMinutes: number) => void;
}

export const EventCard: React.FC<EventCardProps> = ({
  event,
  is24h = false,
  compact = false,
  hasConflict = false,
  onClick,
  onDelete,
  onDuplicate,
  onAdjustDuration,
}) => {
  const scheme = COLOR_SCHEMES[event.color] || COLOR_SCHEMES.indigo;
  const categoryConfig = CATEGORIES.find((c) => c.id === event.category);

  return (
    <div
      id={`event-card-${event.id}`}
      onClick={onClick}
      className={`group relative h-full w-full rounded-2xl border p-2.5 sm:p-3 transition-all duration-150 cursor-pointer select-none overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-lg hover:z-20 ${
        scheme.bg
      } ${scheme.border} ${scheme.text}`}
      style={{
        touchAction: 'manipulation',
      }}
    >
      {/* Left colored glowing indicator strip */}
      <div
        className={`absolute left-0 top-0 bottom-0 w-1 ${scheme.accent} rounded-l-2xl`}
      />

      {/* Top row: Title and time */}
      <div>
        <div className="flex items-start justify-between gap-1">
          <div className="min-w-0 flex-1 pl-1">
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${scheme.accent}`} />
              {event.code && (
                <span className="text-[10px] font-bold tracking-widest uppercase text-neutral-400 font-mono">
                  {event.code}
                </span>
              )}
            </div>
            <h4 className="text-xs sm:text-sm font-bold truncate leading-snug text-white">
              {event.title}
            </h4>
          </div>

          {/* Conflict warning badge */}
          {hasConflict && (
            <span
              className="text-rose-400 bg-rose-500/10 border border-rose-500/30 rounded-full p-0.5 shrink-0"
              title="Time conflict detected with another event"
            >
              <AlertCircle className="w-3.5 h-3.5" />
            </span>
          )}
        </div>

        {/* Time and duration with quick interactive adjusters */}
        <div className="flex items-center flex-wrap gap-1.5 text-[11px] font-mono text-neutral-400 mt-1 pl-1">
          <Clock className="w-3 h-3 shrink-0 text-neutral-500" />
          <span className="truncate">
            {formatDisplayTime(event.startTime, is24h)} - {formatDisplayTime(event.endTime, is24h)}
          </span>
          <span className="text-[10px] text-neutral-500 bg-neutral-900/80 px-1.5 py-0.5 rounded-md border border-neutral-800">
            {getDurationString(event.startTime, event.endTime)}
          </span>

          {/* Quick interactive duration buttons */}
          {onAdjustDuration && (
            <div
              className="inline-flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => onAdjustDuration(-15)}
                className="px-1 py-0.2 rounded text-[9px] font-bold font-mono bg-[#1c1c1c] hover:bg-neutral-700 text-neutral-300 hover:text-white border border-neutral-700 transition"
                title="Decrease duration by 15 mins"
              >
                -15m
              </button>
              <button
                type="button"
                onClick={() => onAdjustDuration(15)}
                className="px-1 py-0.2 rounded text-[9px] font-bold font-mono bg-blue-950/80 hover:bg-blue-900 text-blue-300 hover:text-white border border-blue-600/40 transition"
                title="Increase duration by 15 mins"
              >
                +15m
              </button>
            </div>
          )}
        </div>

        {/* Location & Instructor (visible when space permits or non-compact) */}
        {!compact && (
          <div className="mt-1.5 space-y-0.5 text-[11px] pl-1 text-neutral-400">
            {event.location && (
              <div className="flex items-center gap-1.5 truncate">
                <MapPin className="w-3 h-3 shrink-0 text-neutral-500" />
                <span className="truncate">{event.location}</span>
              </div>
            )}
            {event.instructor && (
              <div className="flex items-center gap-1.5 truncate">
                <User className="w-3 h-3 shrink-0 text-neutral-500" />
                <span className="truncate">{event.instructor}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom row: Category badge & hover quick action buttons */}
      <div className="flex items-center justify-between gap-1 mt-2 pt-1.5 border-t border-neutral-800/60 pl-1">
        {categoryConfig && (
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${scheme.badge} ${scheme.badgeText} truncate max-w-[120px]`}>
            {categoryConfig.label}
          </span>
        )}

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {onDuplicate && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDuplicate(e);
              }}
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              title="Duplicate event"
            >
              <Copy className="w-3 h-3" />
            </button>
          )}
          {onDelete && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(e);
              }}
              className="p-1 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/20 transition"
              title="Delete event"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
