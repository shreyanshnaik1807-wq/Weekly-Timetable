import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      id="offline-status-banner"
      className="fixed bottom-6 left-6 z-50 flex items-center gap-2.5 rounded-full bg-[#161616] text-amber-300 border border-amber-500/40 px-4 py-2.5 text-xs font-mono shadow-[0_0_15px_rgba(245,158,11,0.2)] animate-in slide-in-from-bottom-2 duration-200 backdrop-blur-md"
    >
      <WifiOff className="w-4 h-4 animate-pulse shrink-0 text-amber-400" />
      <span>Offline Mode — Changes saved locally to this device.</span>
    </div>
  );
};
