import React, { useState, useEffect, useRef } from 'react';
import { Plus, Clock } from 'lucide-react';
import { DayOfWeek, DAYS_OF_WEEK, WORK_DAYS, ScheduleEvent, ScheduleSettings } from '../types';
import {
  timeToMinutes,
  minutesToTime,
  getCurrentDayOfWeek,
  getCurrentTimeMinutes,
  formatDisplayTime,
  getDurationString,
  doEventsOverlap,
} from '../utils/time';
import { EventCard } from './EventCard';

interface WeekGridProps {
  events: ScheduleEvent[];
  settings: ScheduleSettings;
  searchQuery?: string;
  categoryFilter?: string;
  onSelectEvent: (event: ScheduleEvent) => void;
  onAddEventAtSlot: (day: DayOfWeek, startTime: string) => void;
  onDeleteEvent: (id: string) => void;
  onDuplicateEvent: (event: ScheduleEvent) => void;
  onAdjustDuration?: (eventId: string, deltaMinutes: number) => void;
  onUpdateEventTime?: (eventId: string, startTime: string, endTime: string) => void;
}

export const WeekGrid: React.FC<WeekGridProps> = ({
  events,
  settings,
  searchQuery = '',
  categoryFilter = 'all',
  onSelectEvent,
  onAddEventAtSlot,
  onDeleteEvent,
  onDuplicateEvent,
  onAdjustDuration,
  onUpdateEventTime,
}) => {
  const { startHour, endHour, timeStep, showWeekends, timeFormat24h } = settings;
  const daysToShow = showWeekends ? DAYS_OF_WEEK : WORK_DAYS;

  // Real-time clock for the current time indicator
  const [nowMinutes, setNowMinutes] = useState(getCurrentTimeMinutes());
  const today = getCurrentDayOfWeek();

  // Resizing state for interactive drag-to-resize duration
  const [resizing, setResizing] = useState<{
    eventId: string;
    initialY: number;
    initialHeight: number;
    currentHeight: number;
    startMinutes: number;
    newEndMinutes: number;
    startTime: string;
  } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setNowMinutes(getCurrentTimeMinutes());
    }, 60000); // update every minute
    return () => clearInterval(timer);
  }, []);

  const ROW_HEIGHT = 72; // px per hour
  const PIXELS_PER_MINUTE = ROW_HEIGHT / 60;
  const gridStartMinutes = startHour * 60;
  const gridEndMinutes = endHour * 60;
  const totalGridHeight = (endHour - startHour) * ROW_HEIGHT;

  // Global pointer handlers for drag-resizing lecture duration
  useEffect(() => {
    if (!resizing) return;

    const handlePointerMove = (e: PointerEvent) => {
      const deltaY = e.clientY - resizing.initialY;
      const rawHeight = Math.max(ROW_HEIGHT / 4, resizing.initialHeight + deltaY);
      // Snap to 15-minute intervals
      const snapMinutes = Math.max(15, Math.round((rawHeight / ROW_HEIGHT) * 60 / 15) * 15);
      const newEndM = Math.min(23 * 60 + 59, resizing.startMinutes + snapMinutes);
      const snappedHeight = (snapMinutes / 60) * ROW_HEIGHT;

      setResizing((prev) =>
        prev
          ? {
              ...prev,
              currentHeight: snappedHeight,
              newEndMinutes: newEndM,
            }
          : null
      );
    };

    const handlePointerUp = () => {
      if (resizing && onUpdateEventTime) {
        const finalEndTime = minutesToTime(resizing.newEndMinutes);
        onUpdateEventTime(resizing.eventId, resizing.startTime, finalEndTime);
      }
      setResizing(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [resizing, onUpdateEventTime, ROW_HEIGHT]);

  // Generate hour slots
  const hours: number[] = [];
  for (let h = startHour; h <= endHour; h++) {
    hours.push(h);
  }

  // Filter events according to search and category
  const filteredEvents = events.filter((ev) => {
    if (categoryFilter !== 'all' && ev.category !== categoryFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = ev.title.toLowerCase().includes(q);
      const matchCode = ev.code?.toLowerCase().includes(q);
      const matchLoc = ev.location?.toLowerCase().includes(q);
      const matchInst = ev.instructor?.toLowerCase().includes(q);
      return matchTitle || matchCode || matchLoc || matchInst;
    }
    return true;
  });

  // Helper to compute side-by-side positioning for overlapping events in the same day
  const getEventLayout = (dayEvents: ScheduleEvent[], event: ScheduleEvent) => {
    // Find all events that overlap with this one
    const overlapping = dayEvents.filter((other) => doEventsOverlap(event, other));
    if (overlapping.length === 0) {
      return { leftPercent: 0, widthPercent: 100, hasConflict: false };
    }

    // Sort overlapping group by id or start time to have deterministic index
    const allInCluster = [event, ...overlapping].sort((a, b) => {
      const timeDiff = timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
      if (timeDiff !== 0) return timeDiff;
      return a.id.localeCompare(b.id);
    });

    // Remove duplicates
    const uniqueCluster = allInCluster.filter((v, i, a) => a.findIndex((t) => t.id === v.id) === i);
    const index = uniqueCluster.findIndex((e) => e.id === event.id);
    const count = uniqueCluster.length;

    const widthPercent = 100 / count;
    const leftPercent = index * widthPercent;

    return {
      leftPercent,
      widthPercent,
      hasConflict: true,
    };
  };

  // Current time line calculation
  const isNowInGrid = nowMinutes >= gridStartMinutes && nowMinutes <= gridEndMinutes;
  const nowTopPosition = (nowMinutes - gridStartMinutes) * PIXELS_PER_MINUTE;

  return (
    <div id="timetable-week-container" className="w-full bg-[#111111] rounded-3xl lg:rounded-[2.5rem] border border-neutral-800 overflow-hidden flex flex-col shadow-2xl">
      {/* Scrollable Container with sticky headers */}
      <div className="overflow-x-auto overflow-y-visible relative scrollbar-thin">
        <div className="min-w-[800px] w-full flex flex-col">
          {/* Day Headers Row */}
          <div className="flex border-b border-neutral-800 bg-[#0d0d0d]/95 backdrop-blur-md sticky top-0 z-30">
            {/* Time gutter header */}
            <div className="w-16 sm:w-20 shrink-0 p-3 text-center border-r border-neutral-800 text-[11px] font-bold text-neutral-500 flex items-center justify-center">
              <Clock className="w-3.5 h-3.5" />
            </div>

            {/* Day columns headers */}
            {daysToShow.map((day) => {
              const isToday = day === today;
              const countForDay = filteredEvents.filter((e) => e.day === day).length;

              return (
                <div
                  key={day}
                  className={`flex-1 min-w-[130px] p-3 text-center border-r last:border-r-0 border-neutral-800 transition-colors ${
                    isToday ? 'bg-blue-600/10' : ''
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span
                      className={`text-xs sm:text-sm font-bold tracking-tight ${
                        isToday ? 'text-blue-400' : 'text-white'
                      }`}
                    >
                      {day}
                    </span>
                    {isToday && (
                      <span className="px-2 py-0.5 text-[9px] font-black uppercase tracking-wider bg-blue-600 text-white rounded-full shadow-[0_0_8px_rgba(37,99,235,0.6)]">
                        Today
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] font-mono text-neutral-500 mt-0.5 flex items-center justify-center gap-1">
                    <span>{countForDay} {countForDay === 1 ? 'event' : 'events'}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grid Canvas */}
          <div className="flex relative bg-[#111111]" style={{ height: `${totalGridHeight}px` }}>
            {/* Time labels column */}
            <div className="w-16 sm:w-20 shrink-0 border-r border-neutral-800 bg-[#0d0d0d] select-none relative">
              {hours.map((h, i) => {
                const top = i * ROW_HEIGHT;
                const timeString = `${String(h).padStart(2, '0')}:00`;
                return (
                  <div
                    key={h}
                    className="absolute right-2.5 -top-2.5 text-[11px] font-mono font-medium text-neutral-500 select-none text-right"
                    style={{ top: `${top}px` }}
                  >
                    {formatDisplayTime(timeString, timeFormat24h)}
                  </div>
                );
              })}
            </div>

            {/* Days columns grid */}
            {daysToShow.map((day) => {
              const isToday = day === today;
              const dayEvents = filteredEvents.filter((e) => e.day === day);

              return (
                <div
                  key={day}
                  id={`week-column-${day.toLowerCase()}`}
                  className={`flex-1 min-w-[130px] border-r last:border-r-0 border-neutral-800/80 relative transition-colors ${
                    isToday ? 'bg-blue-600/[0.04]' : 'hover:bg-neutral-900/30'
                  }`}
                >
                  {/* Horizontal Hour and half-hour Grid Lines */}
                  {hours.map((h, i) => {
                    const top = i * ROW_HEIGHT;
                    const slotTime = `${String(h).padStart(2, '0')}:00`;
                    const halfSlotTime = `${String(h).padStart(2, '0')}:30`;

                    return (
                      <React.Fragment key={h}>
                        {/* Hour line */}
                        <div
                          className="absolute left-0 right-0 border-t border-neutral-800/60 group/slot"
                          style={{ top: `${top}px`, height: `${ROW_HEIGHT}px` }}
                        >
                          {/* Quick Add on click of top half */}
                          <div
                            onClick={() => onAddEventAtSlot(day, slotTime)}
                            className="h-1/2 w-full cursor-pointer group-hover/slot:bg-blue-600/10 flex items-center justify-center opacity-0 group-hover/slot:opacity-100 transition-opacity"
                            title={`Add event at ${formatDisplayTime(slotTime, timeFormat24h)} on ${day}`}
                          >
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-400 bg-[#1a1a1a] px-2.5 py-0.5 rounded-full shadow-md border border-blue-500/30">
                              <Plus className="w-2.5 h-2.5" /> {formatDisplayTime(slotTime, timeFormat24h)}
                            </span>
                          </div>

                          {/* 30 min dashed line */}
                          <div className="absolute left-0 right-0 top-1/2 border-t border-dashed border-neutral-800/40 pointer-events-none" />

                          {/* Quick Add on click of bottom half (30m) */}
                          <div
                            onClick={() => onAddEventAtSlot(day, halfSlotTime)}
                            className="h-1/2 w-full cursor-pointer group-hover/slot:bg-blue-600/10 flex items-center justify-center opacity-0 group-hover/slot:opacity-100 transition-opacity"
                            title={`Add event at ${formatDisplayTime(halfSlotTime, timeFormat24h)} on ${day}`}
                          >
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-400 bg-[#1a1a1a] px-2.5 py-0.5 rounded-full shadow-md border border-blue-500/30">
                              <Plus className="w-2.5 h-2.5" /> {formatDisplayTime(halfSlotTime, timeFormat24h)}
                            </span>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  })}

                  {/* Current Live Time Red Line (Only for today's column) */}
                  {isToday && isNowInGrid && (
                    <div
                      className="absolute left-0 right-0 z-20 pointer-events-none flex items-center"
                      style={{ top: `${nowTopPosition}px` }}
                    >
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.8)] ring-4 ring-rose-500/30 -ml-1 shrink-0 animate-pulse" />
                      <div className="w-full border-t-2 border-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
                      <span className="absolute right-1 text-[9px] font-bold font-mono text-rose-300 bg-[#1f1316] px-1.5 py-0.5 rounded-full border border-rose-500/40 shadow-sm">
                        {formatDisplayTime(minutesToTime(nowMinutes), timeFormat24h)}
                      </span>
                    </div>
                  )}

                  {/* Rendered Event Blocks */}
                  {dayEvents.map((event) => {
                    const startM = timeToMinutes(event.startTime);
                    const endM = timeToMinutes(event.endTime);

                    // Clamp to visible grid
                    const clampedStart = Math.max(gridStartMinutes, startM);
                    const clampedEnd = Math.min(gridEndMinutes, endM);

                    if (clampedEnd <= gridStartMinutes || clampedStart >= gridEndMinutes) {
                      return null; // out of visible hours
                    }

                    const top = (clampedStart - gridStartMinutes) * PIXELS_PER_MINUTE;
                    const durationM = Math.max(25, clampedEnd - clampedStart);
                    const height = durationM * PIXELS_PER_MINUTE;

                    const isResizingThis = resizing?.eventId === event.id;
                    const renderedHeight = isResizingThis ? resizing.currentHeight : height;

                    const layout = getEventLayout(dayEvents, event);
                    const isCompact = renderedHeight < 50;

                    return (
                      <div
                        key={event.id}
                        className={`absolute p-1 transition-all ${
                          isResizingThis ? 'z-30' : 'z-10'
                        }`}
                        style={{
                          top: `${top}px`,
                          height: `${renderedHeight}px`,
                          left: `${layout.leftPercent}%`,
                          width: `${layout.widthPercent}%`,
                        }}
                      >
                        <div className="relative w-full h-full group/cardwrap">
                          <EventCard
                            event={
                              isResizingThis
                                ? {
                                    ...event,
                                    endTime: minutesToTime(resizing.newEndMinutes),
                                  }
                                : event
                            }
                            is24h={timeFormat24h}
                            compact={isCompact}
                            hasConflict={layout.hasConflict}
                            onClick={() => onSelectEvent(event)}
                            onDelete={(e) => {
                              e.stopPropagation();
                              onDeleteEvent(event.id);
                            }}
                            onDuplicate={(e) => {
                              e.stopPropagation();
                              onDuplicateEvent(event);
                            }}
                            onAdjustDuration={
                              onAdjustDuration
                                ? (delta) => onAdjustDuration(event.id, delta)
                                : undefined
                            }
                          />

                          {/* Interactive Drag-to-Resize Handle */}
                          <div
                            onPointerDown={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              const sM = timeToMinutes(event.startTime);
                              const eM = timeToMinutes(event.endTime);
                              setResizing({
                                eventId: event.id,
                                initialY: e.clientY,
                                initialHeight: height,
                                currentHeight: height,
                                startMinutes: sM,
                                newEndMinutes: eM,
                                startTime: event.startTime,
                              });
                            }}
                            className="absolute -bottom-1 left-2 right-2 h-3.5 cursor-row-resize flex items-center justify-center group/resize z-30 touch-none"
                            title="Drag to adjust lecture duration"
                          >
                            <div className="w-8 h-1 rounded-full bg-neutral-600/80 group-hover/resize:bg-blue-400 group-hover/resize:w-14 transition-all shadow-xs" />
                          </div>

                          {/* Live tooltip while dragging duration */}
                          {isResizingThis && (
                            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 z-50 bg-blue-600 text-white font-mono text-[10px] font-bold px-2.5 py-1 rounded-full shadow-2xl border border-blue-400 whitespace-nowrap pointer-events-none flex items-center gap-1.5 animate-in fade-in zoom-in-95">
                              <Clock className="w-3 h-3" />
                              <span>
                                {getDurationString(
                                  event.startTime,
                                  minutesToTime(resizing.newEndMinutes)
                                )}{' '}
                                • Ends{' '}
                                {formatDisplayTime(
                                  minutesToTime(resizing.newEndMinutes),
                                  timeFormat24h
                                )}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
