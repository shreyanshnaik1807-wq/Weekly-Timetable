import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  MapPin,
  User,
  Tag,
  Palette,
  AlignLeft,
  Calendar,
  AlertTriangle,
  Trash2,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  Sliders,
} from 'lucide-react';
import { CATEGORIES, COLOR_SCHEMES } from '../constants/colors';
import { DAYS_OF_WEEK, DayOfWeek, EventCategory, EventColor, ScheduleEvent } from '../types';
import {
  formatDisplayTime,
  getDurationString,
  getDurationMinutes,
  timeToMinutes,
  minutesToTime,
  shiftTimePeriod,
  findConflictingEvents,
} from '../utils/time';

const DURATION_PRESETS = [
  { label: '30m', mins: 30 },
  { label: '45m', mins: 45 },
  { label: '50m (Lecture)', mins: 50 },
  { label: '1h', mins: 60 },
  { label: '1h 15m', mins: 75 },
  { label: '1h 30m', mins: 90 },
  { label: '2h', mins: 120 },
  { label: '3h', mins: 180 },
];

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (eventData: Omit<ScheduleEvent, 'id'>, id?: string, alsoDays?: DayOfWeek[]) => void;
  onDelete?: (id: string) => void;
  onDuplicate?: (event: ScheduleEvent) => void;
  initialEvent?: Partial<ScheduleEvent> | null;
  existingEvents: ScheduleEvent[];
  is24h?: boolean;
}

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  onDuplicate,
  initialEvent,
  existingEvents,
  is24h = false,
}) => {
  const isEditing = !!initialEvent?.id;

  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [day, setDay] = useState<DayOfWeek>('Monday');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [category, setCategory] = useState<EventCategory>('lecture');
  const [color, setColor] = useState<EventColor>('indigo');
  const [location, setLocation] = useState('');
  const [instructor, setInstructor] = useState('');
  const [notes, setNotes] = useState('');
  const [alsoDays, setAlsoDays] = useState<DayOfWeek[]>([]);
  const [showRecurring, setShowRecurring] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Sync state when modal opens or initialEvent changes
  useEffect(() => {
    if (isOpen) {
      setTitle(initialEvent?.title || '');
      setCode(initialEvent?.code || '');
      setDay(initialEvent?.day || 'Monday');
      setStartTime(initialEvent?.startTime || '09:00');
      setEndTime(initialEvent?.endTime || '10:00');
      setCategory(initialEvent?.category || 'lecture');
      setColor(initialEvent?.color || 'indigo');
      setLocation(initialEvent?.location || '');
      setInstructor(initialEvent?.instructor || '');
      setNotes(initialEvent?.notes || '');
      setAlsoDays([]);
      setShowRecurring(false);
      setValidationError('');
    }
  }, [isOpen, initialEvent]);

  if (!isOpen) return null;

  // Real-time conflict check
  const dummyEvent: ScheduleEvent = {
    id: initialEvent?.id || 'temp',
    title,
    code,
    day,
    startTime,
    endTime,
    category,
    color,
    location,
    instructor,
    notes,
  };

  const conflicts = findConflictingEvents(dummyEvent, existingEvents);

  const currentDurationMinutes = getDurationMinutes(startTime, endTime);

  // Quick duration preset click
  const handleApplyPresetDuration = (mins: number) => {
    const startM = timeToMinutes(startTime);
    const newEndM = Math.min(23 * 60 + 59, startM + mins);
    setEndTime(minutesToTime(newEndM));
    setValidationError('');
  };

  // Quick increment/decrement duration by delta minutes
  const handleStepDuration = (deltaMins: number) => {
    const startM = timeToMinutes(startTime);
    const newDuration = Math.max(15, currentDurationMinutes + deltaMins);
    const newEndM = Math.min(23 * 60 + 59, startM + newDuration);
    setEndTime(minutesToTime(newEndM));
    setValidationError('');
  };

  // Slider change for duration
  const handleSliderDurationChange = (newMinutes: number) => {
    const startM = timeToMinutes(startTime);
    const newEndM = Math.min(23 * 60 + 59, startM + newMinutes);
    setEndTime(minutesToTime(newEndM));
    setValidationError('');
  };

  // Shift whole time period earlier or later
  const handleShiftPeriod = (deltaMins: number) => {
    const shifted = shiftTimePeriod(startTime, endTime, deltaMins);
    setStartTime(shifted.startTime);
    setEndTime(shifted.endTime);
    setValidationError('');
  };

  // When user changes start time, preserve existing duration automatically
  const handleStartTimeChange = (newStart: string) => {
    setStartTime(newStart);
    const startM = timeToMinutes(newStart);
    const duration = currentDurationMinutes > 0 ? currentDurationMinutes : 60;
    const newEndM = Math.min(23 * 60 + 59, startM + duration);
    setEndTime(minutesToTime(newEndM));
    setValidationError('');
  };

  const handleEndTimeChange = (newEnd: string) => {
    setEndTime(newEnd);
    setValidationError('');
  };

  const handleCategoryChange = (newCat: EventCategory) => {
    setCategory(newCat);
    const catConfig = CATEGORIES.find((c) => c.id === newCat);
    if (catConfig && !isEditing) {
      setColor(catConfig.defaultColor);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setValidationError('Please enter an event or subject title');
      return;
    }

    const startMin = timeToMinutes(startTime);
    const endMin = timeToMinutes(endTime);

    if (endMin <= startMin) {
      setValidationError('End time must be after start time');
      return;
    }

    setValidationError('');
    onSave(
      {
        title: title.trim(),
        code: code.trim() || undefined,
        day,
        startTime,
        endTime,
        category,
        color,
        location: location.trim() || undefined,
        instructor: instructor.trim() || undefined,
        notes: notes.trim() || undefined,
      },
      initialEvent?.id,
      alsoDays.length > 0 ? alsoDays : undefined
    );
  };

  const toggleAlsoDay = (d: DayOfWeek) => {
    if (d === day) return;
    if (alsoDays.includes(d)) {
      setAlsoDays(alsoDays.filter((x) => x !== d));
    } else {
      setAlsoDays([...alsoDays, d]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-md p-0 sm:p-4 overflow-y-auto">
      <div
        id="event-modal-dialog"
        className="w-full max-w-lg bg-[#111111] rounded-t-3xl sm:rounded-3xl lg:rounded-[2.5rem] shadow-2xl border border-neutral-800 text-white flex flex-col max-h-[92vh] sm:max-h-[85vh] animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-3.5 h-3.5 rounded-full ${COLOR_SCHEMES[color].accent}`}
            />
            <h2 className="text-lg font-black tracking-tight text-white">
              {isEditing ? 'Edit Schedule Event' : 'Add Schedule Event'}
            </h2>
          </div>

          <div className="flex items-center gap-1">
            {isEditing && onDuplicate && initialEvent && (
              <button
                type="button"
                onClick={() => onDuplicate(initialEvent as ScheduleEvent)}
                className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition"
                title="Duplicate event"
              >
                <Copy className="w-4 h-4" />
              </button>
            )}
            {isEditing && onDelete && initialEvent?.id && (
              <button
                type="button"
                onClick={() => onDelete(initialEvent.id!)}
                className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/20 rounded-xl transition"
                title="Delete event"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Validation Alert */}
          {validationError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Conflict Alert */}
          {conflicts.length > 0 && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-xs text-amber-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <span className="font-semibold">Time Conflict:</span> This event overlaps with{' '}
                <span className="font-bold text-amber-200">
                  {conflicts.map((c) => c.title).join(', ')}
                </span>{' '}
                on {day}. Both will be visible.
              </div>
            </div>
          )}

          {/* Title and Code */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2 space-y-1.5">
              <label htmlFor="event-title-input" className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">
                Title / Subject *
              </label>
              <input
                id="event-title-input"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Data Structures, Deep Work"
                className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-neutral-800 rounded-2xl text-sm font-medium text-white placeholder:text-neutral-500 focus:bg-[#222222] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition"
                required
                autoFocus
              />
            </div>
            <div className="col-span-1 space-y-1.5">
              <label htmlFor="event-code-input" className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">
                Code / Tag
              </label>
              <input
                id="event-code-input"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="CS 301"
                className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-neutral-800 rounded-2xl text-sm font-medium uppercase text-white placeholder:text-neutral-500 focus:bg-[#222222] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition font-mono"
              />
            </div>
          </div>

          {/* Day of Week */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">Day of Week</label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
              {DAYS_OF_WEEK.map((d) => {
                const isSelected = day === d;
                const shortLabel = d.slice(0, 3);
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => {
                      setDay(d);
                      setAlsoDays(alsoDays.filter((x) => x !== d));
                    }}
                    className={`py-2 text-xs font-bold rounded-2xl transition ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-[#1a1a1a] hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800'
                    }`}
                  >
                    {shortLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* INTERACTIVE TIME DURATION & PERIOD SECTION */}
          <div className="p-4 bg-[#161616] border border-neutral-800 rounded-2xl space-y-3.5 shadow-inner">
            {/* Header with live duration badge */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white tracking-wide">
                  Time Period & Duration
                </span>
              </div>

              {/* Dynamic Live Duration Badge */}
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 text-xs font-black font-mono bg-blue-600/20 text-blue-300 border border-blue-500/30 rounded-full shadow-sm">
                  Duration: {getDurationString(startTime, endTime)} ({currentDurationMinutes}m)
                </span>
              </div>
            </div>

            {/* Start and End Time Inputs */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="event-start-time" className="block text-[11px] font-semibold text-neutral-400 mb-1">
                  Start Time
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 absolute left-3.5 top-3 text-neutral-500 pointer-events-none" />
                  <input
                    id="event-start-time"
                    type="time"
                    value={startTime}
                    onChange={(e) => handleStartTimeChange(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 bg-[#1f1f1f] border border-neutral-800 rounded-xl text-sm font-mono font-bold text-white focus:bg-[#252525] focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="event-end-time" className="block text-[11px] font-semibold text-neutral-400 mb-1">
                  End Time
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 absolute left-3.5 top-3 text-neutral-500 pointer-events-none" />
                  <input
                    id="event-end-time"
                    type="time"
                    value={endTime}
                    onChange={(e) => handleEndTimeChange(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 bg-[#1f1f1f] border border-neutral-800 rounded-xl text-sm font-mono font-bold text-white focus:bg-[#252525] focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Quick Duration Adjusters & Presets */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-neutral-400">
                  Change Duration:
                </span>
                {/* Stepper buttons */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleStepDuration(-15)}
                    className="px-2 py-0.5 text-xs font-mono font-bold bg-[#222222] hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg border border-neutral-700 transition"
                    title="Shrink duration by 15 mins"
                  >
                    -15m
                  </button>
                  <button
                    type="button"
                    onClick={() => handleStepDuration(15)}
                    className="px-2 py-0.5 text-xs font-mono font-bold bg-[#222222] hover:bg-blue-600/40 text-blue-300 hover:text-white rounded-lg border border-blue-500/40 transition"
                    title="Extend duration by 15 mins"
                  >
                    +15m
                  </button>
                  <button
                    type="button"
                    onClick={() => handleStepDuration(30)}
                    className="px-2 py-0.5 text-xs font-mono font-bold bg-[#222222] hover:bg-blue-600/40 text-blue-300 hover:text-white rounded-lg border border-blue-500/40 transition"
                    title="Extend duration by 30 mins"
                  >
                    +30m
                  </button>
                </div>
              </div>

              {/* Preset duration chips */}
              <div className="flex flex-wrap gap-1.5">
                {DURATION_PRESETS.map((preset) => {
                  const isActive = currentDurationMinutes === preset.mins;
                  return (
                    <button
                      key={preset.mins}
                      type="button"
                      onClick={() => handleApplyPresetDuration(preset.mins)}
                      className={`px-2.5 py-1 text-xs font-bold font-mono rounded-lg transition ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-[0_0_8px_rgba(37,99,235,0.6)]'
                          : 'bg-[#222222] hover:bg-neutral-800 text-neutral-300 border border-neutral-700/60'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Interactive Duration Range Slider */}
            <div className="space-y-1.5 pt-1 border-t border-neutral-800/80">
              <div className="flex items-center justify-between text-[11px] text-neutral-400 font-medium">
                <span className="flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-neutral-500" />
                  <span>Interactive Duration Slider:</span>
                </span>
                <span className="font-mono text-white font-bold">
                  {currentDurationMinutes} mins
                </span>
              </div>
              <input
                type="range"
                min="15"
                max="240"
                step="15"
                value={Math.min(240, Math.max(15, currentDurationMinutes))}
                onChange={(e) => handleSliderDurationChange(Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-neutral-500">
                <span>15m</span>
                <span>1h</span>
                <span>2h</span>
                <span>3h</span>
                <span>4h</span>
              </div>
            </div>

            {/* Shift Whole Lecture Period earlier/later */}
            <div className="flex items-center justify-between pt-1 border-t border-neutral-800/80">
              <span className="text-[11px] font-bold text-neutral-400">
                Shift Lecture Time:
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleShiftPeriod(-15)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-bold bg-[#1f1f1f] hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg border border-neutral-700 transition"
                  title="Shift start & end 15 mins earlier"
                >
                  <ChevronLeft className="w-3 h-3" />
                  <span>-15m</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleShiftPeriod(15)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-bold bg-[#1f1f1f] hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg border border-neutral-700 transition"
                  title="Shift start & end 15 mins later"
                >
                  <span>+15m</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Category Selector */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">Category</label>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((cat) => {
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => handleCategoryChange(cat.id)}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold transition ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-[#1a1a1a] hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Color Theme Selector */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">Card Color</label>
            <div className="flex items-center gap-2.5">
              {(Object.keys(COLOR_SCHEMES) as EventColor[]).map((cKey) => {
                const s = COLOR_SCHEMES[cKey];
                const isSelected = color === cKey;
                return (
                  <button
                    key={cKey}
                    type="button"
                    onClick={() => setColor(cKey)}
                    className={`relative w-8 h-8 rounded-full ${s.accent} transition-transform hover:scale-110 flex items-center justify-center focus:outline-none ring-2 ${
                      isSelected ? 'ring-white' : 'ring-transparent'
                    }`}
                    title={s.name}
                  >
                    {isSelected && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Location and Instructor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label htmlFor="event-location" className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">
                Location / Room
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3.5 top-3 text-neutral-500 pointer-events-none" />
                <input
                  id="event-location"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Auditorium 101 or Zoom link"
                  className="w-full pl-10 pr-3 py-2 bg-[#1a1a1a] border border-neutral-800 rounded-2xl text-sm text-white placeholder:text-neutral-500 focus:bg-[#222222] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="event-instructor" className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">
                Instructor / Host
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3.5 top-3 text-neutral-500 pointer-events-none" />
                <input
                  id="event-instructor"
                  type="text"
                  value={instructor}
                  onChange={(e) => setInstructor(e.target.value)}
                  placeholder="Prof. Wright"
                  className="w-full pl-10 pr-3 py-2 bg-[#1a1a1a] border border-neutral-800 rounded-2xl text-sm text-white placeholder:text-neutral-500 focus:bg-[#222222] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label htmlFor="event-notes" className="block text-xs font-bold text-neutral-400 uppercase tracking-wider font-mono">
              Notes & Preparation
            </label>
            <textarea
              id="event-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Preparation items, textbook readings, or homework deadlines..."
              className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-neutral-800 rounded-2xl text-sm text-white placeholder:text-neutral-500 focus:bg-[#222222] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
            />
          </div>

          {/* Recurrence (Add to multiple days) */}
          {!isEditing && (
            <div className="pt-2 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setShowRecurring(!showRecurring)}
                className="text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>
                  {showRecurring
                    ? 'Hide repeat on other days'
                    : '+ Repeat on other days (e.g. Mon + Wed + Fri)'}
                </span>
              </button>

              {showRecurring && (
                <div className="mt-2.5 p-3.5 bg-[#1a1a1a] rounded-2xl border border-neutral-800">
                  <p className="text-[11px] text-neutral-400 mb-2">
                    Select additional days to duplicate this exact session:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {DAYS_OF_WEEK.filter((d) => d !== day).map((d) => {
                      const isChecked = alsoDays.includes(d);
                      return (
                        <button
                          key={d}
                          type="button"
                          onClick={() => toggleAlsoDay(d)}
                          className={`px-3 py-1.5 text-xs rounded-full font-bold transition ${
                            isChecked
                              ? 'bg-blue-600 text-white'
                              : 'bg-[#111111] text-neutral-400 border border-neutral-800 hover:text-white'
                          }`}
                        >
                          {d.slice(0, 3)}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Modal Footer */}
          <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3 sticky bottom-0 bg-[#111111] py-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-full border border-neutral-800 text-xs sm:text-sm font-bold text-neutral-300 hover:bg-neutral-800 hover:text-white transition active:scale-98"
            >
              Cancel
            </button>
            <button
              id="event-save-btn"
              type="submit"
              className="px-6 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-xs sm:text-sm font-bold text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] transition active:scale-98"
            >
              {isEditing ? 'Save Changes' : 'Create Event'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
