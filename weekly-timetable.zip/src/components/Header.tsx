import React, { useState } from 'react';
import {
  Calendar,
  CalendarDays,
  List,
  Plus,
  Search,
  SlidersHorizontal,
  Download,
  Share2,
  FolderKanban,
  Check,
  ChevronDown,
  Printer,
  Sparkles,
  Settings,
} from 'lucide-react';
import { CATEGORIES } from '../constants/colors';
import { EventCategory, Timetable, ViewMode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  timetables: Timetable[];
  activeTimetable: Timetable;
  onSelectTimetable: (id: string) => void;
  onOpenManageTimetables: () => void;
  viewMode: ViewMode;
  onChangeViewMode: (mode: ViewMode) => void;
  showWeekends: boolean;
  onToggleWeekends: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  categoryFilter: EventCategory | 'all';
  onCategoryFilterChange: (cat: EventCategory | 'all') => void;
  onAddNewEvent: () => void;
  onOpenExportModal: () => void;
  onOpenSettingsModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  timetables,
  activeTimetable,
  onSelectTimetable,
  onOpenManageTimetables,
  viewMode,
  onChangeViewMode,
  showWeekends,
  onToggleWeekends,
  searchQuery,
  onSearchChange,
  categoryFilter,
  onCategoryFilterChange,
  onAddNewEvent,
  onOpenExportModal,
  onOpenSettingsModal,
}) => {
  const [showSearch, setShowSearch] = useState(false);
  const [showScheduleDropdown, setShowScheduleDropdown] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#050505]/95 backdrop-blur-md border-b border-neutral-800/80 shadow-2xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3">
        {/* Top bar: Brand, Active Timetable selector, Primary Actions */}
        <div className="flex items-center justify-between gap-3">
          {/* Brand & Timetable Selector */}
          <div className="flex items-center gap-3">
            {/* Logo */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white border border-neutral-700/50 shadow-[0_0_12px_rgba(37,99,235,0.3)]">
                <CalendarDays className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-base sm:text-lg font-black tracking-tighter text-white leading-tight">
                  PLANAR.
                </h1>
                <p className="text-[10px] text-neutral-500 font-medium uppercase tracking-[0.2em] leading-none">
                  Weekly Rhythm & Flow
                </p>
              </div>
            </div>

            {/* Timetable Selector Dropdown */}
            <div className="relative">
              <button
                id="timetable-selector-dropdown-btn"
                type="button"
                onClick={() => setShowScheduleDropdown(!showScheduleDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#111111] hover:bg-[#1a1a1a] text-xs sm:text-sm font-semibold text-neutral-200 transition border border-neutral-800"
              >
                <FolderKanban className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="truncate max-w-[130px] sm:max-w-[190px]">
                  {activeTimetable.name}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
              </button>

              {showScheduleDropdown && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowScheduleDropdown(false)}
                  />
                  <div className="absolute left-0 mt-2 w-64 rounded-3xl bg-[#111111] p-2.5 shadow-2xl border border-neutral-800 z-50 animate-in fade-in-50 zoom-in-95 duration-100 text-white">
                    <div className="px-2.5 py-1 text-[10px] font-bold text-neutral-500 uppercase tracking-widest font-mono">
                      Your Timetables
                    </div>
                    <div className="space-y-1 my-1.5">
                      {timetables.map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => {
                            onSelectTimetable(t.id);
                            setShowScheduleDropdown(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-2xl text-xs font-semibold text-left transition ${
                            t.id === activeTimetable.id
                              ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                              : 'text-neutral-300 hover:bg-[#1a1a1a] hover:text-white'
                          }`}
                        >
                          <span className="truncate">{t.name}</span>
                          {t.id === activeTimetable.id && (
                            <Check className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="border-t border-neutral-800/80 pt-1.5 mt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setShowScheduleDropdown(false);
                          onOpenManageTimetables();
                        }}
                        className="w-full flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold text-blue-400 hover:bg-blue-500/10 transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Manage / Create Schedules</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Search toggle on mobile */}
            <button
              type="button"
              onClick={() => setShowSearch(!showSearch)}
              className={`p-2 rounded-full border transition ${
                showSearch || searchQuery
                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  : 'bg-[#111111] text-neutral-400 border-neutral-800 hover:text-white hover:bg-[#1a1a1a]'
              }`}
              title="Search events"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Export & Calendar button */}
            <button
              id="export-modal-btn"
              type="button"
              onClick={onOpenExportModal}
              className="p-2 sm:px-3.5 sm:py-2 rounded-full bg-[#111111] border border-neutral-800 hover:bg-[#1a1a1a] hover:text-white text-neutral-300 text-xs font-bold flex items-center gap-1.5 transition"
              title="Export, Print & Calendar Sync"
            >
              <Download className="w-3.5 h-3.5 text-neutral-400" />
              <span className="hidden md:inline">Export</span>
            </button>

            {/* Settings button */}
            <button
              id="settings-modal-btn"
              type="button"
              onClick={onOpenSettingsModal}
              className="p-2 rounded-full bg-[#111111] border border-neutral-800 hover:bg-[#1a1a1a] hover:text-white text-neutral-300 text-xs font-semibold flex items-center justify-center transition"
              title="Timetable Settings"
            >
              <Settings className="w-3.5 h-3.5 text-neutral-400" />
            </button>

            {/* PWA Install Button (Mandatory skill component) */}
            <PWAInstallButton />

            {/* Primary Add Event Button */}
            <button
              id="header-add-event-btn"
              type="button"
              onClick={onAddNewEvent}
              className="inline-flex items-center gap-1.5 px-3.5 sm:px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full text-xs sm:text-sm font-bold shadow-[0_0_16px_rgba(37,99,235,0.4)] transition active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden xs:inline">Add Event</span>
            </button>
          </div>
        </div>

        {/* Search row (collapsible or active) */}
        {showSearch && (
          <div className="mt-2.5 pt-2 border-t border-neutral-800/80 flex items-center gap-2 animate-in fade-in slide-in-from-top-1 duration-150">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-neutral-500" />
              <input
                id="search-timetable-input"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search subject, course code, location, or instructor..."
                className="w-full pl-10 pr-12 py-2 text-xs sm:text-sm bg-[#111111] border border-neutral-800 rounded-2xl text-white placeholder:text-neutral-500 focus:bg-[#161616] focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                autoFocus
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="absolute right-3.5 top-2.5 text-xs text-neutral-400 hover:text-white font-bold"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        )}

        {/* Second bar: View Switcher (Week, Day, Agenda) & Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 mt-2.5 pt-2.5 border-t border-neutral-800/80">
          {/* View Mode Toggle Segmented Control (Bento Pill) */}
          <div className="inline-flex p-1 bg-[#111111] rounded-full border border-neutral-800">
            <button
              id="view-mode-week-btn"
              type="button"
              onClick={() => onChangeViewMode('week')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
                viewMode === 'week'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Week</span>
            </button>

            <button
              id="view-mode-day-btn"
              type="button"
              onClick={() => onChangeViewMode('day')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
                viewMode === 'day'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Day</span>
            </button>

            <button
              id="view-mode-agenda-btn"
              type="button"
              onClick={() => onChangeViewMode('agenda')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
                viewMode === 'agenda'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Agenda</span>
            </button>
          </div>

          {/* Quick Filters: 5 vs 7 Days & Category Dropdown */}
          <div className="flex items-center gap-2">
            {/* Weekends toggle button */}
            <button
              id="toggle-weekends-btn"
              type="button"
              onClick={onToggleWeekends}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border transition ${
                showWeekends
                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  : 'bg-[#111111] text-neutral-400 border-neutral-800 hover:text-white hover:bg-[#1a1a1a]'
              }`}
            >
              {showWeekends ? '7 Days' : '5 Days (Mon-Fri)'}
            </button>

            {/* Category Filter Select */}
            <div className="relative">
              <select
                id="category-filter-select"
                value={categoryFilter}
                onChange={(e) => onCategoryFilterChange(e.target.value as EventCategory | 'all')}
                className="appearance-none pl-3.5 pr-8 py-1.5 rounded-full text-xs font-bold bg-[#111111] border border-neutral-800 text-neutral-300 hover:bg-[#1a1a1a] hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 cursor-pointer"
              >
                <option value="all">All Categories</option>
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#161616] text-white">
                    {c.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-neutral-500 absolute right-3 top-2.5 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
