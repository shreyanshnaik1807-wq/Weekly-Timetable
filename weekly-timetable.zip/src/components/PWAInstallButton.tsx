import React, { useState } from 'react';
import { Download, Smartphone, Share2, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        id="pwa-install-native-btn"
        type="button"
        onClick={install}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:scale-95 rounded-full shadow-[0_0_12px_rgba(37,99,235,0.4)] transition-all focus:outline-none"
        title="Install Weekly Timetable on this device"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install App</span>
        <span className="sm:hidden">Install</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          id="pwa-install-ios-btn"
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 active:scale-95 border border-blue-500/30 rounded-full transition-all focus:outline-none"
          title="Install on iPhone or iPad"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-in fade-in duration-150">
            <div className="w-full max-w-sm rounded-3xl bg-[#111111] p-6 shadow-2xl border border-neutral-800 text-white">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Install on iOS</h3>
                    <p className="text-xs text-neutral-400">Add to your Home Screen</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-sm text-neutral-300">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#1a1a1a] border border-neutral-800/80">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold shrink-0">
                    1
                  </span>
                  <div>
                    <p className="font-bold text-white">Tap the Share button</p>
                    <p className="text-xs text-neutral-400 flex items-center gap-1 mt-0.5">
                      Look for <Share2 className="w-3.5 h-3.5 text-blue-400 inline" /> in your Safari toolbar.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#1a1a1a] border border-neutral-800/80">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold shrink-0">
                    2
                  </span>
                  <div>
                    <p className="font-bold text-white">Add to Home Screen</p>
                    <p className="text-xs text-neutral-400 flex items-center gap-1 mt-0.5">
                      Scroll down and tap <PlusSquare className="w-3.5 h-3.5 text-blue-400 inline" /> &quot;Add to Home Screen&quot;.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#1a1a1a] border border-neutral-800/80">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold shrink-0">
                    3
                  </span>
                  <div>
                    <p className="font-bold text-white">Launch from icon</p>
                    <p className="text-xs text-neutral-400">
                      Open Weekly Timetable directly in full-screen native mode!
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm transition shadow-sm active:scale-98"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Generic fallback button if browser hasn't fired prompt yet or desktop browser
  return (
    <button
      id="pwa-install-generic-btn"
      type="button"
      onClick={() => {
        // Provide gentle guidance
        window.alert
          ? alert('To install on this device, click the Install / Bookmark icon in your browser address bar or menu.')
          : console.log('Install prompt');
      }}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 bg-[#111111] hover:bg-[#1a1a1a] border border-neutral-800 active:scale-95 rounded-full transition-all"
      title="Installable on mobile and desktop"
    >
      <Smartphone className="w-3.5 h-3.5 text-neutral-400" />
      <span className="hidden sm:inline">Installable</span>
    </button>
  );
};
