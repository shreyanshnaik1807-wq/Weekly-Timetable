import { DayOfWeek, DAYS_OF_WEEK, ScheduleEvent } from '../types';

/**
 * Parses "HH:mm" into total minutes from 00:00
 */
export function timeToMinutes(timeStr: string): number {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return (hours || 0) * 60 + (minutes || 0);
}

/**
 * Formats total minutes into "HH:mm"
 */
export function minutesToTime(totalMinutes: number): string {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}

/**
 * Formats "HH:mm" to user display string (12h or 24h)
 */
export function formatDisplayTime(timeStr: string, is24h: boolean = false): string {
  if (!timeStr) return '';
  if (is24h) return timeStr;

  const [hStr, mStr] = timeStr.split(':');
  let h = parseInt(hStr, 10);
  const m = mStr || '00';
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  h = h ? h : 12; // 0 becomes 12
  return `${h}:${m} ${ampm}`;
}

/**
 * Calculates duration in minutes and returns human readable string like "1h 30m"
 */
export function getDurationString(startTime: string, endTime: string): string {
  const startM = timeToMinutes(startTime);
  const endM = timeToMinutes(endTime);
  const diff = Math.max(0, endM - startM);
  const h = Math.floor(diff / 60);
  const m = diff % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

/**
 * Returns the duration in minutes between start and end time
 */
export function getDurationMinutes(startTime: string, endTime: string): number {
  const startM = timeToMinutes(startTime);
  const endM = timeToMinutes(endTime);
  return Math.max(0, endM - startM);
}

/**
 * Adds minutes to a "HH:mm" string, clamped between 00:00 and 23:59
 */
export function addMinutesToTime(timeStr: string, minutesToAdd: number): string {
  const currentMinutes = timeToMinutes(timeStr);
  const newMinutes = Math.min(23 * 60 + 59, Math.max(0, currentMinutes + minutesToAdd));
  return minutesToTime(newMinutes);
}

/**
 * Shifts both startTime and endTime by deltaMinutes, preserving the exact duration
 */
export function shiftTimePeriod(
  startTime: string,
  endTime: string,
  deltaMinutes: number
): { startTime: string; endTime: string } {
  const startM = timeToMinutes(startTime);
  const endM = timeToMinutes(endTime);
  const duration = endM - startM;

  let newStartM = startM + deltaMinutes;
  let newEndM = newStartM + duration;

  // Clamp if before 00:00
  if (newStartM < 0) {
    newStartM = 0;
    newEndM = duration;
  }
  // Clamp if after 23:59
  if (newEndM > 23 * 60 + 59) {
    newEndM = 23 * 60 + 59;
    newStartM = Math.max(0, newEndM - duration);
  }

  return {
    startTime: minutesToTime(newStartM),
    endTime: minutesToTime(newEndM),
  };
}

/**
 * Returns the current day of the week as DayOfWeek
 */
export function getCurrentDayOfWeek(): DayOfWeek {
  const dayIndex = new Date().getDay(); // 0 is Sunday, 1 is Monday ...
  // Match standard starting Monday
  const dayMap: Record<number, DayOfWeek> = {
    0: 'Sunday',
    1: 'Monday',
    2: 'Tuesday',
    3: 'Wednesday',
    4: 'Thursday',
    5: 'Friday',
    6: 'Saturday',
  };
  return dayMap[dayIndex] || 'Monday';
}

/**
 * Returns current time in minutes from midnight
 */
export function getCurrentTimeMinutes(): number {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

/**
 * Checks if two events overlap on the same day
 */
export function doEventsOverlap(e1: ScheduleEvent, e2: ScheduleEvent): boolean {
  if (e1.id === e2.id) return false;
  if (e1.day !== e2.day) return false;

  const start1 = timeToMinutes(e1.startTime);
  const end1 = timeToMinutes(e1.endTime);
  const start2 = timeToMinutes(e2.startTime);
  const end2 = timeToMinutes(e2.endTime);

  return start1 < end2 && start2 < end1;
}

/**
 * Finds all overlapping conflicts for a given event in an event list
 */
export function findConflictingEvents(target: ScheduleEvent, allEvents: ScheduleEvent[]): ScheduleEvent[] {
  return allEvents.filter((ev) => doEventsOverlap(target, ev));
}

/**
 * Generates an iCalendar (.ics) string for the weekly schedule
 */
export function generateICalendar(events: ScheduleEvent[], scheduleName: string): string {
  const dayOffsetMap: Record<DayOfWeek, number> = {
    Monday: 1,
    Tuesday: 2,
    Wednesday: 3,
    Thursday: 4,
    Friday: 5,
    Saturday: 6,
    Sunday: 7,
  };

  // Base date reference (next Monday from now)
  const now = new Date();
  const currentDay = now.getDay();
  const distanceToMonday = (1 + 7 - currentDay) % 7 || 7;
  const baseMonday = new Date(now);
  baseMonday.setDate(now.getDate() + distanceToMonday);

  let ics = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Weekly Timetable App//EN',
    `X-WR-CALNAME:${scheduleName || 'Weekly Timetable'}`,
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
  ];

  events.forEach((ev) => {
    const dayOffset = dayOffsetMap[ev.day] - 1;
    const eventDate = new Date(baseMonday);
    eventDate.setDate(baseMonday.getDate() + dayOffset);

    const [startH, startM] = ev.startTime.split(':').map(Number);
    const [endH, endM] = ev.endTime.split(':').map(Number);

    const formatICSDate = (d: Date, h: number, m: number) => {
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hour = String(h).padStart(2, '0');
      const min = String(m).padStart(2, '0');
      return `${year}${month}${day}T${hour}${min}00`;
    };

    const dtStart = formatICSDate(eventDate, startH, startM);
    const dtEnd = formatICSDate(eventDate, endH, endM);

    const rruleDayCodeMap: Record<DayOfWeek, string> = {
      Monday: 'MO',
      Tuesday: 'TU',
      Wednesday: 'WE',
      Thursday: 'TH',
      Friday: 'FR',
      Saturday: 'SA',
      Sunday: 'SU',
    };

    ics.push(
      'BEGIN:VEVENT',
      `UID:${ev.id}@weeklytimetable.app`,
      `DTSTAMP:${formatICSDate(new Date(), 0, 0)}Z`,
      `DTSTART:${dtStart}`,
      `DTEND:${dtEnd}`,
      `RRULE:FREQ=WEEKLY;BYDAY=${rruleDayCodeMap[ev.day]}`,
      `SUMMARY:${ev.title}${ev.code ? ` (${ev.code})` : ''}`,
      `DESCRIPTION:${(ev.notes || '') + (ev.instructor ? `\\nInstructor: ${ev.instructor}` : '')}`,
      `LOCATION:${ev.location || ''}`,
      `CATEGORIES:${ev.category.toUpperCase()}`,
      'END:VEVENT'
    );
  });

  ics.push('END:VCALENDAR');
  return ics.join('\r\n');
}
