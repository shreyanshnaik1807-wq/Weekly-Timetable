import { PRESET_SCHEDULES } from '../constants/presets';
import { Timetable } from '../types';

const STORAGE_KEY = 'weekly_timetables_app_data_v1';
const ACTIVE_ID_KEY = 'weekly_timetables_active_id_v1';

export interface StorageData {
  timetables: Timetable[];
  activeTimetableId: string;
}

export function loadTimetables(): StorageData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const activeIdRaw = localStorage.getItem(ACTIVE_ID_KEY);

    if (raw) {
      const parsed: Timetable[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const activeId = activeIdRaw && parsed.some((t) => t.id === activeIdRaw)
          ? activeIdRaw
          : parsed[0].id;
        return {
          timetables: parsed,
          activeTimetableId: activeId,
        };
      }
    }
  } catch (err) {
    console.error('Failed to load timetables from localStorage:', err);
  }

  // Fallback to presets
  const initial = PRESET_SCHEDULES;
  saveTimetables(initial, initial[0].id);
  return {
    timetables: initial,
    activeTimetableId: initial[0].id,
  };
}

export function saveTimetables(timetables: Timetable[], activeId?: string): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(timetables));
    if (activeId) {
      localStorage.setItem(ACTIVE_ID_KEY, activeId);
    }
  } catch (err) {
    console.error('Failed to save timetables to localStorage:', err);
  }
}

export function exportTimetablesJSON(timetables: Timetable[]): void {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(timetables, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `weekly-timetable-backup-${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}
