/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Clock,
  CalendarCheck,
  Flame,
  Filter,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  DayOfWeek,
  EventCategory,
  ScheduleEvent,
  ScheduleSettings,
  Timetable,
  ViewMode,
} from './types';
import { PRESET_SCHEDULES } from './constants/presets';
import { loadTimetables, saveTimetables } from './utils/storage';
import { timeToMinutes, minutesToTime, getDurationString, getCurrentDayOfWeek } from './utils/time';
import { Header } from './components/Header';
import { WeekGrid } from './components/WeekGrid';
import { DayView } from './components/DayView';
import { AgendaView } from './components/AgendaView';
import { EventModal } from './components/EventModal';
import { ScheduleManagerModal } from './components/ScheduleManagerModal';
import { ExportModal } from './components/ExportModal';
import { SettingsModal } from './components/SettingsModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  // Load stored timetables or default presets
  const [data, setData] = useState(() => loadTimetables());
  const [activeId, setActiveId] = useState(() => data.activeTimetableId);
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<EventCategory | 'all'>('all');

  // Modals state
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Partial<ScheduleEvent> | null>(null);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    saveTimetables(data.timetables, activeId);
  }, [data.timetables, activeId]);

  // Current active timetable
  const activeTimetable = useMemo(() => {
    return (
      data.timetables.find((t) => t.id === activeId) ||
      data.timetables[0] ||
      PRESET_SCHEDULES[0]
    );
  }, [data.timetables, activeId]);

  // Weekly Stats calculation
  const stats = useMemo(() => {
    const events = activeTimetable.events;
    const totalCount = events.length;

    let totalMinutes = 0;
    const dayCounts: Record<DayOfWeek, number> = {
      Monday: 0,
      Tuesday: 0,
      Wednesday: 0,
      Thursday: 0,
      Friday: 0,
      Saturday: 0,
      Sunday: 0,
    };

    events.forEach((e) => {
      const duration = Math.max(0, timeToMinutes(e.endTime) - timeToMinutes(e.startTime));
      totalMinutes += duration;
      if (dayCounts[e.day] !== undefined) {
        dayCounts[e.day] += 1;
      }
    });

    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    const totalTimeFormatted = mins === 0 ? `${hours}h` : `${hours}h ${mins}m`;

    let busiestDay: DayOfWeek = 'Monday';
    let maxCount = -1;
    (Object.keys(dayCounts) as DayOfWeek[]).forEach((d) => {
      if (dayCounts[d] > maxCount) {
        maxCount = dayCounts[d];
        busiestDay = d;
      }
    });

    return {
      totalCount,
      totalTimeFormatted,
      busiestDay: maxCount > 0 ? busiestDay : 'None',
      busiestCount: maxCount,
    };
  }, [activeTimetable.events]);

  // Handlers for event modifications
  const handleSaveEvent = (
    eventData: Omit<ScheduleEvent, 'id'>,
    existingId?: string,
    alsoDays?: DayOfWeek[]
  ) => {
    setData((prev) => {
      const updatedTimetables = prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;

        let newEvents = [...t.events];

        if (existingId) {
          // Update existing
          newEvents = newEvents.map((ev) =>
            ev.id === existingId ? { ...eventData, id: existingId } : ev
          );
        } else {
          // Add primary event
          const primaryId = `ev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
          newEvents.push({ ...eventData, id: primaryId });

          // If repeated on other days
          if (alsoDays && alsoDays.length > 0) {
            alsoDays.forEach((day) => {
              const repId = `ev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
              newEvents.push({
                ...eventData,
                id: repId,
                day,
              });
            });
          }
        }

        return {
          ...t,
          events: newEvents,
          updatedAt: new Date().toISOString(),
        };
      });

      return {
        ...prev,
        timetables: updatedTimetables,
      };
    });

    setIsEventModalOpen(false);
    setEditingEvent(null);
  };

  const handleDeleteEvent = (id: string) => {
    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;
        return {
          ...t,
          events: t.events.filter((e) => e.id !== id),
          updatedAt: new Date().toISOString(),
        };
      }),
    }));
    setIsEventModalOpen(false);
    setEditingEvent(null);
  };

  const handleDuplicateEvent = (event: ScheduleEvent) => {
    const dupId = `ev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const duplicated: ScheduleEvent = {
      ...event,
      id: dupId,
      title: `${event.title} (Copy)`,
    };

    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;
        return {
          ...t,
          events: [...t.events, duplicated],
          updatedAt: new Date().toISOString(),
        };
      }),
    }));
  };

  // Interactive duration adjustment handler (+/- delta minutes)
  const handleAdjustEventDuration = (eventId: string, deltaMinutes: number) => {
    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;
        return {
          ...t,
          events: t.events.map((e) => {
            if (e.id !== eventId) return e;
            const startM = timeToMinutes(e.startTime);
            const currentEndM = timeToMinutes(e.endTime);
            const currentDuration = Math.max(15, currentEndM - startM);
            const newDuration = Math.max(15, currentDuration + deltaMinutes);
            const newEndM = Math.min(23 * 60 + 59, startM + newDuration);
            return {
              ...e,
              endTime: minutesToTime(newEndM),
            };
          }),
          updatedAt: new Date().toISOString(),
        };
      }),
    }));
  };

  // Direct time update handler (e.g. from drag-to-resize handle)
  const handleUpdateEventTime = (
    eventId: string,
    newStartTime: string,
    newEndTime: string
  ) => {
    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;
        return {
          ...t,
          events: t.events.map((e) =>
            e.id === eventId
              ? { ...e, startTime: newStartTime, endTime: newEndTime }
              : e
          ),
          updatedAt: new Date().toISOString(),
        };
      }),
    }));
  };

  const handleOpenAddAtSlot = (day: DayOfWeek, startTime: string) => {
    const [h, m] = startTime.split(':').map(Number);
    const endMinutes = h * 60 + m + 60; // 1 hour default
    const endHour = Math.floor(endMinutes / 60);
    const endMin = endMinutes % 60;
    const endTime = `${String(endHour).padStart(2, '0')}:${String(endMin).padStart(2, '0')}`;

    setEditingEvent({
      day,
      startTime,
      endTime,
      category: 'lecture',
      color: 'indigo',
    });
    setIsEventModalOpen(true);
  };

  // Schedule management handlers
  const handleCreateTimetable = (name: string, description?: string) => {
    const newId = `tt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newTimetable: Timetable = {
      id: newId,
      name,
      description: description || 'Custom weekly timetable',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      settings: { ...activeTimetable.settings },
      events: [],
    };

    setData((prev) => ({
      timetables: [...prev.timetables, newTimetable],
      activeTimetableId: newId,
    }));
    setActiveId(newId);
  };

  const handleDuplicateTimetable = (sourceId: string) => {
    const source = data.timetables.find((t) => t.id === sourceId);
    if (!source) return;

    const newId = `tt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const cloned: Timetable = {
      ...source,
      id: newId,
      name: `${source.name} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      events: source.events.map((e) => ({
        ...e,
        id: `ev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      })),
    };

    setData((prev) => ({
      timetables: [...prev.timetables, cloned],
      activeTimetableId: newId,
    }));
    setActiveId(newId);
  };

  const handleRenameTimetable = (id: string, newName: string) => {
    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => (t.id === id ? { ...t, name: newName } : t)),
    }));
  };

  const handleDeleteTimetable = (id: string) => {
    if (data.timetables.length <= 1) return;
    const remaining = data.timetables.filter((t) => t.id !== id);
    const newActiveId = remaining[0].id;
    setData({
      timetables: remaining,
      activeTimetableId: newActiveId,
    });
    setActiveId(newActiveId);
  };

  const handleResetPresets = () => {
    setData({
      timetables: PRESET_SCHEDULES,
      activeTimetableId: PRESET_SCHEDULES[0].id,
    });
    setActiveId(PRESET_SCHEDULES[0].id);
  };

  const handleUpdateSettings = (newSettings: Partial<ScheduleSettings>) => {
    setData((prev) => ({
      ...prev,
      timetables: prev.timetables.map((t) => {
        if (t.id !== activeTimetable.id) return t;
        return {
          ...t,
          settings: {
            ...t.settings,
            ...newSettings,
          },
        };
      }),
    }));
  };

  const handleToggleWeekends = () => {
    handleUpdateSettings({
      showWeekends: !activeTimetable.settings.showWeekends,
    });
  };

  const handleImportTimetables = (imported: Timetable[]) => {
    setData({
      timetables: imported,
      activeTimetableId: imported[0].id,
    });
    setActiveId(imported[0].id);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col font-sans antialiased selection:bg-blue-500/30 selection:text-blue-200">
      {/* Top Application Header */}
      <Header
        timetables={data.timetables}
        activeTimetable={activeTimetable}
        onSelectTimetable={(id) => setActiveId(id)}
        onOpenManageTimetables={() => setIsManageModalOpen(true)}
        viewMode={viewMode}
        onChangeViewMode={setViewMode}
        showWeekends={activeTimetable.settings.showWeekends}
        onToggleWeekends={handleToggleWeekends}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        categoryFilter={categoryFilter}
        onCategoryFilterChange={setCategoryFilter}
        onAddNewEvent={() => {
          setEditingEvent({
            day: getCurrentDayOfWeek(),
            startTime: '09:00',
            endTime: '10:00',
            category: 'lecture',
            color: 'indigo',
          });
          setIsEventModalOpen(true);
        }}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
      />

      {/* Sub-header Banner: Bento info & quick stats */}
      <div className="bg-[#0a0a0a] border-b border-neutral-800/80 py-2.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
            <span className="text-xs font-black tracking-tight text-white uppercase font-mono">
              {activeTimetable.name}
            </span>
            {activeTimetable.description && (
              <span className="hidden md:inline text-xs text-neutral-400 font-medium">
                — {activeTimetable.description}
              </span>
            )}
          </div>

          {/* Quick Stats Bento Pills */}
          <div className="flex items-center gap-2 sm:gap-2.5 text-xs font-mono">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#161616] border border-neutral-800 text-neutral-300">
              <CalendarCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>
                <strong className="text-white">{stats.totalCount}</strong> events
              </span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#161616] border border-neutral-800 text-neutral-300">
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span>
                <strong className="text-white">{stats.totalTimeFormatted}</strong> planned
              </span>
            </div>

            {stats.busiestCount > 0 && (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#161616] border border-neutral-800 text-neutral-300">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  Peak: <strong className="text-white">{stats.busiestDay}</strong> ({stats.busiestCount})
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Timetable View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 flex flex-col">
        {viewMode === 'week' && (
          <WeekGrid
            events={activeTimetable.events}
            settings={activeTimetable.settings}
            searchQuery={searchQuery}
            categoryFilter={categoryFilter}
            onSelectEvent={(event) => {
              setEditingEvent(event);
              setIsEventModalOpen(true);
            }}
            onAddEventAtSlot={handleOpenAddAtSlot}
            onDeleteEvent={handleDeleteEvent}
            onDuplicateEvent={handleDuplicateEvent}
            onAdjustDuration={handleAdjustEventDuration}
            onUpdateEventTime={handleUpdateEventTime}
          />
        )}

        {viewMode === 'day' && (
          <DayView
            events={activeTimetable.events}
            settings={activeTimetable.settings}
            searchQuery={searchQuery}
            categoryFilter={categoryFilter}
            onSelectEvent={(event) => {
              setEditingEvent(event);
              setIsEventModalOpen(true);
            }}
            onAddEventAtSlot={handleOpenAddAtSlot}
            onDeleteEvent={handleDeleteEvent}
            onDuplicateEvent={handleDuplicateEvent}
            onAdjustDuration={handleAdjustEventDuration}
          />
        )}

        {viewMode === 'agenda' && (
          <AgendaView
            events={activeTimetable.events}
            settings={activeTimetable.settings}
            searchQuery={searchQuery}
            categoryFilter={categoryFilter}
            onSelectEvent={(event) => {
              setEditingEvent(event);
              setIsEventModalOpen(true);
            }}
            onAddEventAtSlot={handleOpenAddAtSlot}
            onDeleteEvent={handleDeleteEvent}
            onDuplicateEvent={handleDuplicateEvent}
            onAdjustDuration={handleAdjustEventDuration}
          />
        )}
      </main>

      {/* Floating Action Button on mobile */}
      <button
        id="mobile-floating-add-btn"
        type="button"
        onClick={() => {
          setEditingEvent({
            day: getCurrentDayOfWeek(),
            startTime: '09:00',
            endTime: '10:00',
            category: 'lecture',
            color: 'indigo',
          });
          setIsEventModalOpen(true);
        }}
        className="sm:hidden fixed right-5 bottom-6 z-40 w-14 h-14 rounded-full bg-blue-600 text-white shadow-[0_0_24px_rgba(37,99,235,0.6)] border border-blue-400/40 flex items-center justify-center hover:bg-blue-500 active:scale-95 transition"
        title="Add Event"
        aria-label="Add Event"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Event Add/Edit Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => {
          setIsEventModalOpen(false);
          setEditingEvent(null);
        }}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        onDuplicate={handleDuplicateEvent}
        initialEvent={editingEvent}
        existingEvents={activeTimetable.events}
        is24h={activeTimetable.settings.timeFormat24h}
      />

      {/* Manage Timetables Modal */}
      <ScheduleManagerModal
        isOpen={isManageModalOpen}
        onClose={() => setIsManageModalOpen(false)}
        timetables={data.timetables}
        activeTimetableId={activeId}
        onSelectTimetable={(id) => {
          setActiveId(id);
          setIsManageModalOpen(false);
        }}
        onCreateTimetable={handleCreateTimetable}
        onDuplicateTimetable={handleDuplicateTimetable}
        onRenameTimetable={handleRenameTimetable}
        onDeleteTimetable={handleDeleteTimetable}
        onResetPresets={handleResetPresets}
      />

      {/* Export & Sync Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        timetables={data.timetables}
        activeTimetable={activeTimetable}
        onImportTimetables={handleImportTimetables}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={activeTimetable.settings}
        onUpdateSettings={handleUpdateSettings}
      />
    </div>
  );
}
