export type DayOfWeek = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

export const WORK_DAYS: DayOfWeek[] = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
];

export type EventCategory =
  | 'lecture'
  | 'lab'
  | 'seminar'
  | 'study'
  | 'meeting'
  | 'work'
  | 'workout'
  | 'personal'
  | 'other';

export interface CategoryConfig {
  id: EventCategory;
  label: string;
  defaultColor: string; // Tailwind color token or hex
}

export type EventColor =
  | 'indigo'
  | 'emerald'
  | 'amber'
  | 'rose'
  | 'sky'
  | 'violet'
  | 'orange'
  | 'teal';

export interface ColorScheme {
  id: EventColor;
  name: string;
  bg: string;
  border: string;
  text: string;
  accent: string;
  badge: string;
  badgeText: string;
}

export interface ScheduleEvent {
  id: string;
  title: string;
  code?: string; // Course/Task code, e.g. "CS101", "DEV-42"
  day: DayOfWeek;
  startTime: string; // HH:mm (24-hour) e.g. "09:00"
  endTime: string;   // HH:mm (24-hour) e.g. "10:30"
  category: EventCategory;
  color: EventColor;
  location?: string; // Room number, link, building
  instructor?: string; // Teacher, mentor, lead
  notes?: string;
  recurringDays?: DayOfWeek[]; // If occurs on multiple days
}

export interface ScheduleSettings {
  startHour: number; // e.g. 7 (07:00)
  endHour: number;   // e.g. 21 (21:00)
  timeStep: number;  // 30 or 60 (minutes)
  showWeekends: boolean;
  timeFormat24h: boolean;
}

export interface Timetable {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
  settings: ScheduleSettings;
  events: ScheduleEvent[];
}

export type ViewMode = 'week' | 'day' | 'agenda';

export interface FilterState {
  searchQuery: string;
  selectedCategory: EventCategory | 'all';
  selectedDay?: DayOfWeek | 'all';
}
