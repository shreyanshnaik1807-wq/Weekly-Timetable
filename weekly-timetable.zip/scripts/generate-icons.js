import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPNG(width, height, isMaskable = false) {
  // PNG signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8); // bit depth
  ihdrData.writeUInt8(6, 9); // RGBA
  ihdrData.writeUInt8(0, 10); // compression
  ihdrData.writeUInt8(0, 11); // filter
  ihdrData.writeUInt8(0, 12); // interlace

  const ihdrChunk = createChunk('IHDR', ihdrData);

  // Pixel data
  // Scanline length = 1 (filter type 0) + width * 4
  const scanlineLength = 1 + width * 4;
  const rawData = Buffer.alloc(scanlineLength * height);

  const cx = width / 2;
  const cy = height / 2;
  const rCorner = width * 0.22;

  // Background colors: indigo gradient (#4f46e5 to #3730a3)
  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter: None

    const tY = y / height;
    const bgR = Math.round(79 * (1 - tY) + 55 * tY);
    const bgG = Math.round(70 * (1 - tY) + 48 * tY);
    const bgB = Math.round(229 * (1 - tY) + 163 * tY);

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;

      // Maskable icons fill entire canvas with background.
      // Standard icons have rounded squircle.
      let inBounds = true;
      if (!isMaskable) {
        // Squircle / rounded rect boundary check
        const dx = Math.abs(x - cx);
        const dy = Math.abs(y - cy);
        const halfW = width * 0.46;
        const halfH = height * 0.46;
        const cornerR = width * 0.18;

        if (dx > halfW || dy > halfH) {
          inBounds = false;
        } else if (dx > halfW - cornerR && dy > halfH - cornerR) {
          const cornerDist = Math.hypot(dx - (halfW - cornerR), dy - (halfH - cornerR));
          if (cornerDist > cornerR) {
            inBounds = false;
          }
        }
      }

      if (!inBounds) {
        rawData[pxOffset] = 0;
        rawData[pxOffset + 1] = 0;
        rawData[pxOffset + 2] = 0;
        rawData[pxOffset + 3] = 0;
        continue;
      }

      // Inside: calendar card
      // Card rectangle
      const cardMarginX = width * 0.16;
      const cardMarginTop = height * 0.18;
      const cardMarginBottom = height * 0.18;
      const inCard =
        x >= cardMarginX &&
        x <= width - cardMarginX &&
        y >= cardMarginTop &&
        y <= height - cardMarginBottom;

      if (inCard) {
        // Top banner of calendar card
        if (y <= cardMarginTop + height * 0.14) {
          rawData[pxOffset] = 99; // #6366f1
          rawData[pxOffset + 1] = 102;
          rawData[pxOffset + 2] = 241;
          rawData[pxOffset + 3] = 255;
        } else {
          // Inside calendar white surface
          // Draw sample timetable event blocks
          const relX = (x - cardMarginX) / (width - 2 * cardMarginX);
          const relY = (y - (cardMarginTop + height * 0.14)) / (height - cardMarginTop - cardMarginBottom - height * 0.14);

          // Block 1 (Indigo, Mon)
          if (relX >= 0.08 && relX <= 0.34 && relY >= 0.12 && relY <= 0.42) {
            rawData[pxOffset] = 79;
            rawData[pxOffset + 1] = 70;
            rawData[pxOffset + 2] = 229;
            rawData[pxOffset + 3] = 255;
          }
          // Block 2 (Emerald, Wed)
          else if (relX >= 0.38 && relX <= 0.64 && relY >= 0.22 && relY <= 0.65) {
            rawData[pxOffset] = 16;
            rawData[pxOffset + 1] = 185;
            rawData[pxOffset + 2] = 129;
            rawData[pxOffset + 3] = 255;
          }
          // Block 3 (Amber, Fri)
          else if (relX >= 0.68 && relX <= 0.94 && relY >= 0.12 && relY <= 0.38) {
            rawData[pxOffset] = 245;
            rawData[pxOffset + 1] = 158;
            rawData[pxOffset + 2] = 11;
            rawData[pxOffset + 3] = 255;
          }
          // Block 4 (Rose, Mon afternoon)
          else if (relX >= 0.08 && relX <= 0.34 && relY >= 0.48 && relY <= 0.85) {
            rawData[pxOffset] = 244;
            rawData[pxOffset + 1] = 63;
            rawData[pxOffset + 2] = 94;
            rawData[pxOffset + 3] = 255;
          }
          // Block 5 (Sky, Fri afternoon)
          else if (relX >= 0.68 && relX <= 0.94 && relY >= 0.45 && relY <= 0.78) {
            rawData[pxOffset] = 14;
            rawData[pxOffset + 1] = 165;
            rawData[pxOffset + 2] = 233;
            rawData[pxOffset + 3] = 255;
          } else {
            // White card background
            rawData[pxOffset] = 255;
            rawData[pxOffset + 1] = 255;
            rawData[pxOffset + 2] = 255;
            rawData[pxOffset + 3] = 255;
          }
        }
      } else {
        // Outer Indigo Gradient Background
        rawData[pxOffset] = bgR;
        rawData[pxOffset + 1] = bgG;
        rawData[pxOffset + 2] = bgB;
        rawData[pxOffset + 3] = 255;
      }
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = data.length;
  const buffer = Buffer.alloc(8 + length + 4);
  buffer.writeUInt32BE(length, 0);
  buffer.write(type, 4, 4, 'ascii');
  data.copy(buffer, 8);

  const crc = crc32(buffer.subarray(4, 8 + length));
  buffer.writeUInt32BE(crc, 8 + length);
  return buffer;
}

// CRC32 table
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c >>> 0;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPNG(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPNG(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPNG(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), createPNG(64, 64, false));

console.log('Successfully generated PWA icons in /public!');
